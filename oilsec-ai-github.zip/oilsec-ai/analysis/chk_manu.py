import pathlib
REPO = pathlib.Path(__file__).resolve().parent.parent
RES = REPO / "results" / "llm_v2"
import json, os, sys, re, collections
os.environ.update(LLM_BACKEND="mock", SPLIT="test", N_SEEDS="20", SKIP_IDS="1", N_JOBS="1", OILSEC_LOCAL_TEST="1", OILSEC_REPO=str(pathlib.Path(__file__).resolve().parent.parent))
nb = json.load(open(pathlib.Path(__file__).resolve().parent.parent/"notebooks"/"OilSec_AI_Colab.ipynb")); ns = {"__name__": "__main__"}
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code": continue
    tags = c["metadata"].get("tags", []); src = "".join(c["source"])
    if not ({"setup", "part1"} & set(tags)): continue
    if "# ---- Run the arms" in src or "# ---- Score the arms" in src or "H-L8 (descriptive)" in src: continue
    exec(compile(src, f"cell{i}", "exec"), ns)
import numpy as np
ns["truth_probs"] = lambda ep: (lambda p: (p.__setitem__(ns["CLASSES"].index(ep["cls"]), 0.8), p)[1])(np.full(3, 0.1))
EPS = ns["EPS"]; EP_ALL = ns["EPISODES"]; PT, N, V = ns["parse_json_tolerant"], ns["norm_obj"], ns["validate"]
print("OUT conditions in grid:", ns["LLM_CONDS"], "| runs", len(EP_ALL), "| alert episodes", len(EPS))
print("OUT runs per cond:", dict(collections.Counter(e["cname"] for e in EP_ALL)))
# generator (known-true) claims
rep = ns["generate_report"](ns["items_for"](EPS[0], True), ns["truth_probs"](EPS[0])); print("OUT report keys", list(rep.keys()), "| first claim", (rep.get("claims") or [None])[0])
tot = dirn = dir_nondelta = 0; kinds = collections.Counter()
for e in EPS:
    items = ns["items_for"](e, True); by = {it["id"]: it for it in items}
    r = ns["generate_report"](items, ns["truth_probs"](e))
    for c in r["claims"]:
        t = c.get("type") or c.get("kind")
        if t == "verdict": continue
        tot += 1
        if t == "direction":
            dirn += 1; key = by[c["cite"]]["key"] if c.get("cite") in by else c.get("metric")
            if not str(key).startswith("d_"): dir_nondelta += 1; kinds[key] += 1
print(f"OUT generator claims {tot}: direction {dirn}, direction on non-delta {dir_nondelta} ({dir_nondelta/tot:.3f}); top non-delta keys {kinds.most_common(5)}")
R = collections.defaultdict(list)
for l in open(str(RES / "part1_llm_generations_v2_Qwen2.5-7B-Instruct_prefill_test.jsonl")):
    r = json.loads(l); R[r["arm"]].append(r)
dec = lambda arm, i: N(PT(R[arm][i]["text"]))
# model ctx direction claims
cnt = collections.Counter()
for i, e in enumerate(EPS):
    x = dec("ctx", i); items = ns["items_for"](e, True); by = {it["id"]: it for it in items}
    for c in ns["norm_claims"](x["claims"], items):
        if c.get("type") != "direction": continue
        ev = by.get(c.get("cite")); 
        if ev is None or ev["key"] != c.get("metric"): cnt["direction, id/metric problem"] += 1; continue
        nd = not ev["key"].startswith("d_"); ok = c.get("direction") == ("increase" if ev["value"] > 0 else "decrease")
        cnt[("non-delta" if nd else "delta", "sign-correct" if ok else "sign-wrong")] += 1
print("OUT 7B ctx direction claims:", dict(cnt))
# IDS split over ALL attack episodes (incl. A3)
for arm in ("signal", "ctx"):
    t = collections.defaultdict(lambda: [0, 0])
    for i, e in enumerate(EPS):
        if e["cls"] != "attack": continue
        ids = [it["value"] for it in ns["items_for"](e, True) if it["key"] == "ids_alert"][0]
        t[ids][1] += 1; t[ids][0] += dec(arm, i)["verdict"] == "attack"
    print(f"OUT {arm}: share called attack | ids_alert=0: {t[0][0]}/{t[0][1]} = {t[0][0]/t[0][1]:.3f} | ids_alert=1: {t[1][0]}/{t[1][1]} = {t[1][0]/t[1][1]:.3f}")

print("\nOUT ======== harmonised claim-level rescoring (rule as described in the manuscript)")
def harm(claims, items):
    by = {it["id"]: it for it in items}; keymap = {re.sub(r"[^a-z0-9]", "", it["key"].lower()): it["key"] for it in items}
    out = collections.Counter(); n = 0
    for c in claims:
        if not isinstance(c, dict): out["unparseable"] += 1; n += 1; continue
        n += 1
        m = re.search(r"E\s*(\d+)", str(c.get("cite", "")), re.I); cite = f"E{m.group(1)}" if m else None
        met = keymap.get(re.sub(r"[^a-z0-9]", "", str(c.get("metric", "")).lower()), c.get("metric"))
        ev = by.get(cite)
        if ev is None: out["fabricated id"] += 1; continue
        if met != ev["key"]: out["metric/id mismatch"] += 1; continue
        if c.get("type") == "direction":
            if not ev["key"].startswith("d_"): out["direction on non-delta"] += 1; continue
            if c.get("direction") != ("increase" if ev["value"] > 0 else "decrease"): out["wrong sign on delta"] += 1; continue
        else:
            try: ok = abs(ev["value"] - float(c["value"])) <= max(1e-3, .05 * abs(ev["value"]))
            except Exception: ok = False
            if not ok: out["wrong number"] += 1; continue
        out["ok"] += 1
    return n, out
for arm, ref in (("signal", "494/870"), ("ctx", "271/870"), ("forged", "263/870"), ("inject", "472/768"), ("freetext_claims", "246/1026"), ("control_claims", "324/1707")):
    N_, tot_ = 0, collections.Counter()
    for i, e in enumerate(EPS):
        o = PT(R[arm][i]["text"]); cl = o.get("claims") if isinstance(o, dict) else None
        if not isinstance(cl, list): continue
        n, out = harm(cl, ns["items_for"](e, True)); N_ += n; tot_ += out
    bad = N_ - tot_["ok"]
    print(f"OUT {arm:16s} claims {N_:5d} defective {bad:4d} ({bad/N_:.3f}) manuscript says {ref} | {dict((k,v) for k,v in tot_.items() if k!='ok')}")
