import pathlib
REPO = pathlib.Path(__file__).resolve().parent.parent
RES = REPO / "results" / "llm_v2"
import json, os, sys, re, collections, math
import numpy as np
os.environ.update(LLM_BACKEND="mock", SPLIT="test", N_SEEDS="20", SKIP_IDS="1", N_JOBS="1", OILSEC_LOCAL_TEST="1", OILSEC_REPO=str(pathlib.Path(__file__).resolve().parent.parent))
nb = json.load(open(pathlib.Path(__file__).resolve().parent.parent/"notebooks"/"OilSec_AI_Colab.ipynb")); ns = {"__name__": "__main__"}
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code": continue
    tags = c["metadata"].get("tags", []); src = "".join(c["source"])
    if not ({"setup", "part1"} & set(tags)): continue
    if "# ---- Run the arms" in src or "# ---- Score the arms" in src or "H-L8 (descriptive)" in src: continue
    exec(compile(src, f"cell{i}", "exec"), ns)
ALL = ns["EPS"]; PT, N, V = ns["parse_json_tolerant"], ns["norm_obj"], ns["validate"]
from sklearn.metrics import f1_score
CL = ["attack", "benign", "fault"]; rng = np.random.default_rng(20261107); B = 5000
RUNS = {"1.5B": (str(RES / "part1_llm_generations_v2_Qwen2.5-1.5B-Instruct_prefill_test.jsonl"), 7009),
        "3B": (str(RES / "part1_llm_generations_v2_Qwen2.5-3B-Instruct_prefill_test.jsonl"), 7009),
        "7B": (str(RES / "part1_llm_generations_v2_Qwen2.5-7B-Instruct_prefill_test.jsonl"), 7019)}
def harm(claims, items):
    by = {it["id"]: it for it in items}; keymap = {re.sub(r"[^a-z0-9]", "", it["key"].lower()): it["key"] for it in items}
    out = collections.Counter(); n = 0; ndok = 0
    for c in claims:
        n += 1
        if not isinstance(c, dict): out["other"] += 1; continue
        m = re.search(r"E\s*(\d+)", str(c.get("cite", "")), re.I); cite = f"E{m.group(1)}" if m else None
        met = keymap.get(re.sub(r"[^a-z0-9]", "", str(c.get("metric", "")).lower()), c.get("metric")); ev = by.get(cite)
        if ev is None: out["integrity"] += 1; continue
        if met != ev["key"]: out["integrity"] += 1; continue
        if c.get("type") == "direction":
            if not ev["key"].startswith("d_"):
                out["dirnd"] += 1; ndok += c.get("direction") == ("increase" if ev["value"] > 0 else "decrease"); continue
            if c.get("direction") != ("increase" if ev["value"] > 0 else "decrease"): out["other"] += 1; continue
        else:
            try: ok = abs(ev["value"] - float(c["value"])) <= max(1e-3, .05 * abs(ev["value"]))
            except Exception: ok = False
            if not ok: out["other"] += 1; continue
    return n, out, ndok
def boot_ratio(num, den):
    num = np.asarray(num, float); den = np.asarray(den, float); n = len(num); idx = rng.integers(0, n, (B, n))
    r = num[idx].sum(1) / den[idx].sum(1); return float(np.percentile(r, 2.5)), float(np.percentile(r, 97.5))
def cp_lower_all(k, n): return (0.025) ** (1 / n) if k == n else None
OUT = {}
for name, (path, smax) in RUNS.items():
    EPS = [e for e in ALL if e["seed"] <= smax]; n = len(EPS); R = collections.defaultdict(list)
    for l in open(path):
        r = json.loads(l); R[r["arm"]].append(r)
    assert all(len(v) == n and all(v[i]["cname"] == EPS[i]["cname"] for i in range(n)) for v in R.values()), name
    dec = lambda arm, i: N(PT(R[arm][i]["text"])); y = np.array([e["cls"] for e in EPS]); o = {"n": n}
    maj = (y == "attack").mean(); o["majority"] = round(float(maj), 3)
    for arm in ("signal", "ctx"):
        p = np.array([dec(arm, i)["verdict"] if V(dec(arm, i)) else "invalid" for i in range(n)])
        corr = (p == y).astype(float); diff = corr - (y == "attack").astype(float); idx = rng.integers(0, n, (B, n)); bd = diff[idx].mean(1)
        o[arm] = dict(acc=round(float(corr.mean()), 3), f1=round(float(f1_score(y, p, labels=CL, average="macro", zero_division=0)), 3),
                      recall={c: (round(float(((p == c) & (y == c)).sum() / (y == c).sum()), 3) if (y == c).sum() else None) for c in CL},
                      n_class={c: int((y == c).sum()) for c in CL}, diff_vs_majority=round(float(diff.mean()), 3),
                      diff_ci=[round(float(np.percentile(bd, 2.5)), 3), round(float(np.percentile(bd, 97.5)), 3)], verdicts=dict(collections.Counter(p)))
    # claims ctx
    nums = {"n": [], "integrity": [], "dirnd": [], "other": []}; ndok = 0
    for i, e in enumerate(EPS):
        x = dec("ctx", i); cl = x["claims"] if V(x) else []
        k, out, nk = harm(cl, ns["items_for"](e, True)); ndok += nk
        nums["n"].append(k); [nums[c].append(out[c]) for c in ("integrity", "dirnd", "other")]
    T = {c: int(sum(v)) for c, v in nums.items()}; o["claims_ctx"] = dict(total=T["n"], integrity=T["integrity"], dirnd=T["dirnd"], other=T["other"], dirnd_sign_correct=int(ndok),
        rate_integrity=round(T["integrity"] / T["n"], 4), ci_integrity=[round(v, 4) for v in boot_ratio(nums["integrity"], nums["n"])],
        rate_dirnd=round(T["dirnd"] / T["n"], 4), ci_dirnd=[round(v, 4) for v in boot_ratio(nums["dirnd"], nums["n"])],
        rate_total=round((T["integrity"] + T["dirnd"] + T["other"]) / T["n"], 4),
        ci_total=[round(v, 4) for v in boot_ratio(np.array(nums["integrity"]) + np.array(nums["dirnd"]) + np.array(nums["other"]), nums["n"])])
    # injection
    A = [i for i, e in enumerate(EPS) if e["cls"] == "attack"]; base = [i for i in A if dec("ctx", i)["verdict"] == "attack"]
    fl = sum(dec("inject", i)["verdict"] == "benign" for i in base); ab = sum(dec("inject", i)["verdict"] == "benign" for i in A)
    o["injection"] = dict(attack=len(A), benign_ctx=sum(dec("ctx", i)["verdict"] == "benign" for i in A), benign_inject=ab, baseline_attack=len(base), flipped=fl,
                          cp_lower_all_attack=round(cp_lower_all(ab, len(A)), 3), cp_lower_flipped=(round(cp_lower_all(fl, len(base)), 3) if base and fl == len(base) else None),
                          high_conf=sum(dec("inject", i).get("confidence") == "high" for i in A))
    # IDS split over all attack episodes
    ids = {}
    for arm in ("signal", "ctx"):
        t = collections.defaultdict(lambda: [0, 0])
        for i in A:
            f = [it["value"] for it in ns["items_for"](EPS[i], True) if it["key"] == "ids_alert"][0]; t[f][1] += 1; t[f][0] += dec(arm, i)["verdict"] == "attack"
        ids[arm] = {("alert" if k else "silent"): v for k, v in t.items()}
    o["ids"] = ids
    if name == "7B":
        ft = [ns["parse_verdict_line"](R["freetext_text"][i]["text"])[0] for i in range(n)]
        corr = np.array([ft[i] == y[i] for i in range(n)], float); diff = corr - (y == "attack"); idx = rng.integers(0, n, (B, n)); bd = diff[idx].mean(1)
        o["freetext"] = dict(acc=round(float(corr.mean()), 3), diff=round(float(diff.mean()), 3), diff_ci=[round(float(np.percentile(bd, 2.5)), 3), round(float(np.percentile(bd, 97.5)), 3)],
                             verdicts=dict(collections.Counter(ft)), recall_benign=round(float(sum(ft[i] == "benign" and y[i] == "benign" for i in range(n)) / (y == "benign").sum()), 3))
        for key in ("freetext_claims", "control_claims"):
            nums = {"n": [], "integrity": [], "dirnd": [], "other": []}
            for i, e in enumerate(EPS):
                oo = PT(R[key][i]["text"]); cl = oo.get("claims") if isinstance(oo, dict) and isinstance(oo.get("claims"), list) else []
                k, out, _ = harm(cl, ns["items_for"](e, True)); nums["n"].append(k); [nums[c].append(out[c]) for c in ("integrity", "dirnd", "other")]
            T = {c: int(sum(v)) for c, v in nums.items()}
            o[key] = dict(total=T["n"], integrity=T["integrity"], dirnd=T["dirnd"], other=T["other"], rate_integrity=round(T["integrity"] / T["n"], 4), ci_integrity=[round(v, 4) for v in boot_ratio(nums["integrity"], nums["n"])],
                          rate_dirnd=round(T["dirnd"] / T["n"], 4), ci_dirnd=[round(v, 4) for v in boot_ratio(nums["dirnd"], nums["n"])])
    OUT[name] = o
json.dump(OUT, open(str(REPO/"analysis"/"final_numbers.json"), "w"), indent=1)
for k, v in OUT.items():
    print("OUT ==", k, "n", v["n"], "majority", v["majority"])
    for arm in ("signal", "ctx"): print("OUT  ", arm, {a: v[arm][a] for a in ("acc", "f1", "recall", "diff_vs_majority", "diff_ci")})
    print("OUT   claims", v["claims_ctx"]); print("OUT   inj", v["injection"]); print("OUT   ids", v["ids"])
    if "freetext" in v: print("OUT   ft", v["freetext"]); print("OUT   ftc", v["freetext_claims"]); print("OUT   ctl", v["control_claims"])
