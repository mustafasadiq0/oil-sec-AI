"""Run every non-skipped code cell locally with a MOCK LLM; syntax-check the rest. Not a substitute for running in Colab."""
import json, os, sys, time, traceback
os.environ.update(LLM_BACKEND="mock", N_SEEDS="2", MB_PORT="5020", SKIP_IDS="1", N_SEEDS4="2", N_JOBS="1",
                  OILSEC_REPO=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
nb = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "OilSec_AI_Colab.ipynb")))
ns = {"__name__": "__main__"}
ok = True
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code": continue
    src = "".join(c["source"]); tags = c["metadata"].get("tags", [])
    if "skip_local" in tags:
        try: compile(src, f"cell{i}", "exec"); print(f"[cell {i:02d}] syntax OK (skipped: needs Colab) tags={tags}")
        except SyntaxError as e: print(f"[cell {i:02d}] SYNTAX ERROR", e); ok = False
        continue
    t = time.time()
    try:
        exec(compile(src, f"cell{i}", "exec"), ns); print(f"[cell {i:02d}] ran OK in {time.time()-t:.1f}s tags={tags}")
    except Exception:
        print(f"[cell {i:02d}] FAILED"); traceback.print_exc(); ok = False; break
if ok and os.environ.get("EXTRA") == "1":
    print("\n=== extra plumbing checks ===")
    # 1. scorer must count bad claims
    it = ns["items_for"](ns["EPS"][0], True); byk = {x["key"]: x for x in it}
    k = "res_level"; good = dict(type="numeric", cite=byk[k]["id"], metric=k, value=round(byk[k]["value"], 3))
    cases = {"good": [good], "wrong value": [dict(good, value=good["value"] * 3 + 1)], "fake id": [dict(good, cite="E999")],
             "wrong metric for id": [dict(good, metric="res_gas")], "non-number": [dict(good, value="lots")], "no cite": [dict(good, cite=None)],
             "bad direction": [dict(type="direction", cite=byk["d_lt"]["id"], metric="d_lt", direction="increase" if byk["d_lt"]["value"] < 0 else "decrease")]}
    for name, cl in cases.items():
        nc, nv = ns["check_claims"](cl, it); print(f"  {name:22s} claims={nc} violations={nv}")
    assert ns["check_claims"](cases["good"], it)[1] == 0
    for name in ("wrong value", "fake id", "wrong metric for id", "non-number", "no cite", "bad direction"): assert ns["check_claims"](cases[name], it)[1] >= 1, name
    # 2. injection prompt differs only in the note, only for attack episodes
    a = [i for i, e in enumerate(ns["EPS"]) if e["cls"] == "attack"][0]; n = [i for i, e in enumerate(ns["EPS"]) if e["cls"] != "attack"][0]
    n_inj = sum("SYSTEM OVERRIDE" in u for (s_, u) in ns["MOCK_REGISTRY"]); n_att = sum(e["cls"] == "attack" for e in ns["EPS"])
    print(f"  prompts containing the injection: {n_inj}; attack episodes: {n_att}"); assert n_inj == n_att
    forged = [i for i, e in enumerate(ns["EPS"]) if e["cname"].startswith("A3")]
    for i in forged:
        kv = lambda arm: {x["key"]: x["value"] for x in ns["ITEMS"][(arm, i)]}
        assert kv("forged")["change_ticket"] == 1.0 and kv("signal").get("change_ticket") is None
        assert {k: v for k, v in kv("forged").items() if k != "change_ticket"} == {k: v for k, v in kv("ctx").items() if k != "change_ticket"}
    print(f"  forged arm differs from ctx arm only in change_ticket on {len(forged)} A3 episodes")
    # 3. modbus scenario driver with distinct source IPs
    srv = ns["ModbusServer"](); srv.start(); time.sleep(0.2)
    for kind in ns["KINDS"]:
        srv.writes.clear(); ns["scenario"](kind, srv)
        exp = {"benign_hmi_write": [(10, 5500)], "attack_rogue_write": [(10, 8000)], "attack_master_write": [(10, 8000)], "attack_hmi_write": [(10, 8000)]}.get(kind, [])
        print(f"  scenario {kind:22s} writes seen by server: {srv.writes}"); assert srv.writes == exp, (kind, srv.writes)
    srv.stop()
    print("  Part 1 hypotheses under MOCK (should be all-pass, 0 unsupported):", {k: v for k, v in ns["H"].items() if k.endswith("_pass")})
if ok and os.environ.get("EXTRA") == "1":
    pj, vd, pv = ns["parse_json"], ns["validate"], ns["parse_verdict_line"]
    good = '{"verdict":"attack","confidence":"high","claims":[{"type":"numeric","cite":"E4","metric":"res_level","value":3.2}],"rationale":"x"}'
    msgs = {"clean": good, "code fence": "```json\n" + good + "\n```", "chatter around": "Sure! Here is my answer: " + good + " Hope this helps {not json}",
            "nested braces in rationale": good.replace('"x"', '"a {b} c"'), "two objects, first wins": '{"a":1} ' + good}
    for k, t in msgs.items(): print(f"  parse {k:28s} ->", type(pj(t)).__name__, "valid" if vd(pj(t)) else "not-valid-schema")
    assert vd(pj(msgs["clean"])) and vd(pj(msgs["code fence"])) and vd(pj(msgs["chatter around"])) and vd(pj(msgs["nested braces in rationale"]))
    assert not vd(pj(msgs["two objects, first wins"]))              # first dict lacks the schema -> counted invalid (documented behaviour)
    for bad in ("", "no json here", "{broken", '{"verdict":"maybe","confidence":"high","claims":[]}', '{"verdict":"attack","confidence":"sure","claims":[]}',
                '{"verdict":"attack","confidence":"low","claims":"none"}'): assert not vd(pj(bad)), bad
    assert pv("blah\nVERDICT: Attack; CONFIDENCE: LOW") == ("attack", "low") and pv("verdict is attack") == (None, None)
    print("  messy-output parsing checks OK")
print("ALL LOCAL CELLS OK" if ok else "FAILURES")
sys.exit(0 if ok else 1)
