from build_colab_part1 import md, code, CELLS
import build_colab_part2  # noqa: F401  (registers part 2 cells)

md(r"""
---
# Part 3 — Neural detector baseline: LSTM auto-encoder (needs PyTorch)

## Question
Step 2 compared a physics-consistency detector (D4) with CUSUM and an IsolationForest. A reviewer would ask for a
**learned sequence model**. Does a small LSTM auto-encoder (D5) do better than D3 on weak attacks when benign events are
treated as hard negatives, using exactly the same protocol (zero-training-alert threshold, 40 training runs, seeds 3000-3019)?

## Pre-registered prediction (before running)
D5 will **not** beat D4: weak-attack AUC against benign-event negatives `AUC_hard(D5) < AUC_hard(D4)`. Reason: weak attacks
are within the range of benign variation, and reconstruction error should flag benign events as readily as in D3 (AUC 0.34).
The prediction is **falsified** if `AUC_hard(D5) >= AUC_hard(D4)` on the weak set. TPR at the training-derived threshold is
reported but AUC is the primary (threshold-free) measure. Threats: tiny model, untuned, one architecture, 40 training runs.
""")

code(r"""
# ---- D5: LSTM auto-encoder as a repo Detector (leakage-guarded by the base class) ------------------------------
import torch, torch.nn as nn
from oilsec.detect.base import Detector, sustained
CH = ["LT101", "PT101", "TT101", "FT101", "FT102", "ZT101", "ZT102", "u_level_calc", "u_press_calc"]

class _Net(nn.Module):
    def __init__(self, d_in, hid):
        super().__init__(); self.enc = nn.LSTM(d_in, hid, batch_first=True); self.dec = nn.LSTM(hid, hid, batch_first=True); self.out = nn.Linear(hid, d_in)
    def forward(self, x):
        _, (h, _) = self.enc(x); z = h[-1].unsqueeze(1).repeat(1, x.shape[1], 1)
        y, _ = self.dec(z); return self.out(y)

class LSTMAEDetector(Detector):
    name = "D5_lstmae"
    def __init__(self, win=30, hid=32, epochs=12, seed=0):
        super().__init__(); self.win, self.hid, self.epochs, self.seed = win, hid, epochs, seed
    def _wins(self, X, idx): return np.stack([X[i - self.win + 1:i + 1] for i in idx])
    def _fit(self, runs):
        torch.manual_seed(self.seed); np.random.seed(self.seed)
        allv = pd.concat([r[CH].iloc[120:] for r in runs]); self.mu, self.sd = allv.mean().values, np.maximum(allv.std().values, 1e-6)
        Wn = np.concatenate([self._wins((r[CH].values - self.mu) / self.sd, range(120 + self.win, len(r), 5)) for r in runs])
        Wt = torch.tensor(Wn, dtype=torch.float32); self.net = _Net(len(CH), self.hid)
        opt = torch.optim.Adam(self.net.parameters(), lr=1e-3)
        for ep in range(self.epochs):
            perm = torch.randperm(len(Wt)); tot = 0.0
            for b in range(0, len(Wt), 256):
                xb = Wt[perm[b:b + 256]]; opt.zero_grad(); loss = ((self.net(xb) - xb) ** 2).mean(); loss.backward(); opt.step(); tot += float(loss) * len(xb)
            print(f"  epoch {ep + 1}/{self.epochs} loss {tot / len(Wt):.4f}", end="\r")
        self.net.eval()
    def _score(self, o):
        X = (o[CH].values - self.mu) / self.sd; n = len(X); s = np.zeros(n); idx = list(range(120 + self.win, n, 5))
        with torch.no_grad():
            Wt = torch.tensor(self._wins(X, idx), dtype=torch.float32); err = ((self.net(Wt) - Wt) ** 2).mean(dim=(1, 2)).numpy()
        for j, i in enumerate(idx): s[i:i + 5] = err[j]
        return s
""", tags=("part3", "skip_local"))

code(r"""
# ---- Evaluate D5 vs D3/D4 on weak attacks, normal AND benign-event negatives -----------------------------------
from exp02_collect import conditions, training_runs, make_dets, T0, DUR
from oilsec.sim.runner import simulate, SimConfig
from oilsec.detect.base import sustained
COND = conditions()
WEAK = ["A1_-1", "A1_-2", "A4_45", "A4_40", "A5_-0.0005", "A5_-0.001"]
EVAL = WEAK + ["A3_60", "A4_5", "A5_-0.01"]
tr = training_runs(1)
_d = make_dets()
D3, D4 = _d[2].fit(tr), _d[3].fit(tr)
t = time.time(); D5 = LSTMAEDetector().fit(tr); print(f"\nD5 trained in {time.time()-t:.0f}s, threshold {D5.thr:.4f}")
DD = [D3, D4, D5]
def auc(pos, neg): return float(np.mean([(p > n) + 0.5 * (p == n) for p in pos for n in neg]))
SEEDS_E = range(3000, 3020)
wl = {c: COND[c][2] for c in EVAL}
neg_norm = {d.name: [] for d in DD}; neg_ben = {d.name: [] for d in DD}
for s in range(3000, 3030):
    df = simulate(SimConfig(seed=s, duration_s=DUR))
    for d in DD: ss = sustained(d.score(df)); neg_norm[d.name].append({c: float(ss[T0:wl[c]].max()) for c in EVAL})
for b in ("B1", "B2", "B3"):
    for s in SEEDS_E:
        df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(COND[b][0])))
        for d in DD: ss = sustained(d.score(df)); neg_ben[d.name].append({c: float(ss[T0:wl[c]].max()) for c in EVAL})
RES3 = {}
for c in EVAL:
    ev, _, wend = COND[c]; pk = {d.name: [] for d in DD}; hit = {d.name: 0 for d in DD}
    for s in SEEDS_E:
        df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(ev)))
        for d in DD:
            ss = sustained(d.score(df)); pk[d.name].append(float(ss[T0:wend].max()))
            a = ss > d.thr; edges = np.where(a & ~np.concatenate([[False], a[:-1]]))[0]; hit[d.name] += int(((edges >= T0) & (edges < wend)).any())
    RES3[c] = {d.name: dict(auc_normal=round(auc(pk[d.name], [x[c] for x in neg_norm[d.name]]), 3),
                            auc_hard=round(auc(pk[d.name], [x[c] for x in neg_ben[d.name]]), 3), tpr=hit[d.name] / len(SEEDS_E)) for d in DD}
    print(c, {n: (v["auc_normal"], v["auc_hard"], v["tpr"]) for n, v in RES3[c].items()}, "(auc_normal, auc_hard, tpr)")
weak_hard = {d.name: round(float(np.mean([RES3[c][d.name]["auc_hard"] for c in WEAK])), 3) for d in DD}
weak_tpr = {d.name: round(float(np.mean([RES3[c][d.name]["tpr"] for c in WEAK])), 3) for d in DD}
print("\nweak-set mean AUC vs benign negatives:", weak_hard, "\nweak-set mean TPR at training threshold:", weak_tpr)
verdict = "CONFIRMED (D5 did not beat D4)" if weak_hard["D5_lstmae"] < weak_hard["D4_twin"] else "FALSIFIED (D5 >= D4)"
print("pre-registered prediction:", verdict)
json.dump(dict(per_condition=RES3, weak_auc_hard=weak_hard, weak_tpr=weak_tpr, prediction=verdict, d5_threshold=float(D5.thr)),
          open(RESULTS / "part3_lstmae.json", "w"), indent=2)
""", tags=("part3", "skip_local"))

md(r"""
---
# Part 4 — Step-2 headline with independent seeds and more seeds (CPU)

Step 2 used the same 20 test seeds for every condition (clustered backgrounds, 5% granularity). Here each condition gets its
**own** seeds (`7000 + 1000*condition_index + k`), `N_SEEDS4` per condition (default 40), parallel over cores.

## Pre-registered predictions (before running)
* Twin (D4) weak-set TPR >= 0.90; D1 and D3 <= 0.10 (as in Step 2). D2 expected near 0.3.
* One-sided exact McNemar, D4 vs each other detector, Holm alpha = 0.05: all rejected (same rule as Step 2).
* A3_55 stays <= 10% for every detector (indistinguishable from the benign operator change B3 by construction).
If D4's weak-set TPR falls below 0.90 with independent seeds, the Step-2 headline was partly an artefact of shared seeds.
""")

code(r"""
# ---- Part 4: independent-seed re-run of the Step-2 weak-attack comparison ----------------------------------------
from joblib import Parallel, delayed
from exp02_collect import conditions, make_dets, training_runs, T0, DUR
from oilsec.sim.runner import simulate, SimConfig
from oilsec.triage.evidence import DETS
COND4 = conditions()
P4_CONDS = ["A1_-1", "A1_-2", "A4_45", "A4_40", "A5_-0.0005", "A5_-0.001", "A3_55", "A3_60", "A3_65", "B3", "F2"]
WEAK4 = P4_CONDS[:6]
N4 = int(os.environ.get("N_SEEDS4", 40))
NJ = int(os.environ.get("N_JOBS", -1))
if "d" not in globals().get("_DETS_CACHE", {}):
    _DETS_CACHE = globals().get("_DETS_CACHE", {}); _tr = training_runs(1); _DETS_CACHE["d"] = [d.fit(_tr) for d in make_dets()[:4]]
dets4 = _DETS_CACHE["d"]

def edge_in_window(a, lo, hi):
    e = np.where(a & ~np.concatenate([[False], a[:-1]]))[0]
    return bool(((e >= lo) & (e < hi)).any())

def run_cond(ci, cname, dets, n):
    ev, cls, wend = COND4[cname]; rows = []
    for k in range(n):
        s = 7000 + 1000 * ci + k
        df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(ev)))
        for nm, d in zip(DETS, dets): rows.append(dict(cond=cname, cls=cls, seed=s, det=nm, detected=edge_in_window(d.alerts(df), T0, wend)))
    return rows

t = time.time()
parts = Parallel(n_jobs=NJ)(delayed(run_cond)(ci, c, dets4, N4) for ci, c in enumerate(P4_CONDS))
R4 = pd.DataFrame([r for p in parts for r in p]); print(f"{len(R4)} rows in {time.time()-t:.0f}s")
tab = R4.groupby(["cond", "det"]).detected.mean().unstack("det")[DETS]
print("\nTPR / alert-rate per condition (independent seeds, n =", N4, "each)\n", tab.round(2))
W = R4[R4.cond.isin(WEAK4)].pivot_table(index=["cond", "seed"], columns="det", values="detected", aggfunc="first").astype(bool)
weak_tpr = {d: (float(W[d].mean()), wilson(int(W[d].sum()), len(W))) for d in DETS}
print("\nweak-set TPR with 95% Wilson CI:", {d: (round(v[0], 3), v[1]) for d, v in weak_tpr.items()})
tests = []
for o in ("D1", "D2", "D3"):
    b = int((W["D4"] & ~W[o]).sum()); c = int((~W["D4"] & W[o]).sum())
    p = float(stats.binomtest(b, b + c, 0.5, alternative="greater").pvalue) if b + c else 1.0
    tests.append(dict(vs=o, twin_only=b, other_only=c, p=p))
order = np.argsort([x["p"] for x in tests]); m = len(tests)
for rank, i in enumerate(order): tests[i]["p_holm"] = float(min(1.0, max(tests[j]["p"] * (m - r) for r, j in enumerate(order[:rank + 1]))))
for x in tests: print(x)
checks = dict(twin_ge_0_90=weak_tpr["D4"][0] >= 0.90, d1_d3_le_0_10=(weak_tpr["D1"][0] <= 0.10 and weak_tpr["D3"][0] <= 0.10),
              all_holm_reject=all(x["p_holm"] < 0.05 for x in tests), A3_55_le_0_10=bool(tab.loc["A3_55"].max() <= 0.10))
print("\npre-registered predictions:", checks)
tab.to_csv(RESULTS / "part4_tpr_table.csv"); R4.to_csv(RESULTS / "part4_runs.csv", index=False)
json.dump(dict(n_per_condition=N4, weak_tpr=weak_tpr, mcnemar=tests, predictions=checks), open(RESULTS / "part4_results.json", "w"), indent=2, default=str)
""", tags=("part4",))

md(r"""
---
# Part 5 — Package results and send them back

Download `colab_results.zip` and upload it to the chat. It contains: `part1_llm_results.json` and `part1_llm_generations.jsonl`
(every raw model output), `part2_ids_empirical.json` and the capture/rules/eve.json, `part3_lstmae.json`, `part4_*`.
**Do not edit the pre-registration cells after seeing results.** If you change prompts, models or thresholds, say so when you upload.
""")

code(r"""
import shutil
zip_path = shutil.make_archive(str(REPO / "colab_results"), "zip", RESULTS)
print("created", zip_path, "contents:", sorted(p.name for p in RESULTS.iterdir()))
if IN_COLAB:
    from google.colab import files
    files.download(zip_path)
""", tags=("part5", "skip_local"))
