"""Assemble OilSec_AI_Colab.ipynb from the cell definitions. Usage: python3 assemble_colab.py"""
import json, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_colab_part3 as b
from build_colab_part1 import CELLS

def to_nb():
    cells = []
    for i, (kind, src, tags) in enumerate(CELLS):
        c = {"cell_type": kind, "metadata": {"id": f"c{i:02d}", "tags": list(tags)}, "source": src.splitlines(True)}
        if kind == "code": c.update(execution_count=None, outputs=[])
        cells.append(c)
    return {"nbformat": 4, "nbformat_minor": 5, "cells": cells,
            "metadata": {"accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4", "name": "OilSec_AI_Colab.ipynb"},
                         "kernelspec": {"name": "python3", "display_name": "Python 3"}, "language_info": {"name": "python"}}}

if __name__ == "__main__":
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "OilSec_AI_Colab.ipynb")
    json.dump(to_nb(), open(out, "w"), indent=1)
    print("wrote", out, "cells:", len(CELLS), "code cells:", sum(k == "code" for k, _, _ in CELLS))
