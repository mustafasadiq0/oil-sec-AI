from build_colab_part1 import md, code

md(r"""
---
# Part 2 — Real IDS (Suricata) on real Modbus/TCP traffic (CPU, needs root + apt)

## Why
In Notebook 05 the provenance signal `ids_alert` used an **assumed** detection probability (`p_ids = 0.5` for every attack).
Here a real IDS parses real Modbus frames, so we can see *which attack classes a basic rule set can and cannot see*.

## Design
A minimal Modbus/TCP server (function codes 3, 6, 16) serves the register map of the separator; a "SCADA master" polls it
(simulator data); other hosts are simulated with distinct loopback source IPs
(`127.0.0.1` poller, `127.0.0.4` HMI/engineering, `127.0.0.9` rogue). Traffic is captured with `tcpdump` on `lo`
and analysed offline by Suricata with two local rules:
1. TCP to port 502 from a host that is **not** a known poller/HMI;
2. a Modbus **write** from any host except the HMI/engineering host.

## Predictions (written before running; rules make them near-deterministic, so deviations = pipeline/rule bug)
| Scenario | Expected P(alert) | Reason |
|---|---|---|
| poll_only | 0 | whitelisted reads |
| benign_hmi_write | 0 | write from HMI is allowed |
| attack_rogue_write | 1 | rule 1 and 2 |
| attack_master_write | 1 | rule 2 (poller never writes) |
| attack_hmi_write | **0** | compromised engineering host looks like a legitimate operator at network level |
| attack_gateway_spoof | **0** | register values altered at the server; wire protocol normal |
| attack_recon | 1 | rule 1 |
| fault_sensor_stuck | 0 | no network trace |

**What this does and does not show:** it checks the pipeline end-to-end and shows the *structure* of IDS visibility
(network-write attacks visible, host-compromise and sensor-spoof attacks invisible to this rule set). The numbers are
near-0/1 *by rule construction*; any overall `p_ids` depends on the attacker mix I assume (weights below).
Loopback only: no real network noise, no encrypted/tunnelled traffic, no vendor-specific function codes.
""")

code(r"""
# ---- Minimal Modbus/TCP server and client (pure sockets; no pymodbus API dependence) ---------------------------
import socket, struct, threading, datetime as dt
PORT = int(os.environ.get("MB_PORT", 502))
MASTER, HMI, ROGUE = "127.0.0.1", "127.0.0.4", "127.0.0.9"
REG = dict(LT101=0, PT101=1, TT101=2, FT101=3, FT102=4, ZT101=5, ZT102=6, sp_level=10, sp_press=11, u_level=12)

class ModbusServer(threading.Thread):
    def __init__(self, host="127.0.0.1", port=PORT, n_regs=64):
        super().__init__(daemon=True); self.regs = [0] * n_regs; self.lock = threading.Lock(); self.stop_flag = False; self.writes = []
        self.sock = socket.socket(); self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((host, port)); self.sock.listen(16); self.sock.settimeout(0.2)
    def run(self):
        while not self.stop_flag:
            try: c, _ = self.sock.accept()
            except socket.timeout: continue
            threading.Thread(target=self._serve, args=(c,), daemon=True).start()
    def stop(self): self.stop_flag = True; self.join(timeout=2); self.sock.close()
    @staticmethod
    def _recvn(c, n):
        buf = b""
        while len(buf) < n:
            chunk = c.recv(n - len(buf))
            if not chunk: return None
            buf += chunk
        return buf
    def _serve(self, c):
        c.settimeout(5.0)
        try:
            while True:
                h = self._recvn(c, 7)
                if h is None: break
                tid, pid, ln, uid = struct.unpack(">HHHB", h)
                pdu = self._recvn(c, ln - 1)
                if pdu is None: break
                resp = self._process(pdu)
                c.sendall(struct.pack(">HHHB", tid, 0, len(resp) + 1, uid) + resp)
        except (socket.timeout, OSError): pass
        finally: c.close()
    def _process(self, pdu):
        fc = pdu[0]
        with self.lock:
            if fc == 3:
                a, n = struct.unpack(">HH", pdu[1:5])
                if n < 1 or n > 125 or a + n > len(self.regs): return bytes([0x83, 2])
                return bytes([3, 2 * n]) + b"".join(struct.pack(">H", self.regs[a + i]) for i in range(n))
            if fc == 6:
                a, v = struct.unpack(">HH", pdu[1:5])
                if a >= len(self.regs): return bytes([0x86, 2])
                self.regs[a] = v; self.writes.append((a, v)); return pdu[:5]
            if fc == 16:
                a, n, bc = struct.unpack(">HHB", pdu[1:6])
                if a + n > len(self.regs) or bc != 2 * n: return bytes([0x90, 3])
                for i, v in enumerate(struct.unpack(">" + "H" * n, pdu[6:6 + 2 * n])): self.regs[a + i] = v; self.writes.append((a + i, v))
                return struct.pack(">BHH", 16, a, n)
        return bytes([fc | 0x80, 1])

class ModbusClient:
    def __init__(self, src_ip, host="127.0.0.1", port=PORT, unit=1):
        self.s = socket.socket(); self.s.settimeout(3); self.s.bind((src_ip, 0)); self.s.connect((host, port)); self.tid = 0; self.unit = unit
    def _rpc(self, pdu):
        self.tid = (self.tid + 1) & 0xFFFF
        self.s.sendall(struct.pack(">HHHB", self.tid, 0, len(pdu) + 1, self.unit) + pdu)
        h = ModbusServer._recvn(self.s, 7); ln = struct.unpack(">HHHB", h)[2]
        return ModbusServer._recvn(self.s, ln - 1)
    def read(self, a, n):
        r = self._rpc(struct.pack(">BHH", 3, a, n))
        if r[0] & 0x80: raise IOError(f"modbus exception {r[1]}")
        return list(struct.unpack(">" + "H" * n, r[2:2 + 2 * n]))
    def write(self, a, v):
        r = self._rpc(struct.pack(">BHH", 6, a, v))
        if r[0] & 0x80: raise IOError(f"modbus exception {r[1]}")
    def write_many(self, a, vals):
        r = self._rpc(struct.pack(">BHHB", 16, a, len(vals), 2 * len(vals)) + b"".join(struct.pack(">H", v) for v in vals))
        if r[0] & 0x80: raise IOError(f"modbus exception {r[1]}")
    def close(self): self.s.close()

def enc(x): return int(max(0, min(65535, round(x * 100))))
def push(server, row):
    with server.lock:
        for k in ("LT101", "PT101", "TT101", "FT101", "FT102", "ZT101", "ZT102"): server.regs[REG[k]] = enc(row[k])
        server.regs[REG["sp_level"]], server.regs[REG["sp_press"]] = enc(row["sp_level"]), enc(row["sp_press"])
        server.regs[REG["u_level"]] = enc(row["u_level_calc"])
""", tags=("part2",))

code(r"""
# ---- Scenario driver ---------------------------------------------------------------------------------------
from oilsec.sim.runner import simulate, SimConfig
BASE = simulate(SimConfig(seed=8000, duration_s=600)).reset_index(drop=True)
STEPS, ACT = 30, 15
POLL_SPAN = REG["u_level"] + 1

def scenario(kind, server):
    m = ModbusClient(MASTER); other = None
    spoof_offset, frozen = 0.0, None
    for k in range(STEPS):
        row = BASE.iloc[100 + 5 * k].copy()
        if kind == "attack_gateway_spoof" and k >= ACT: row["LT101"] += -35.0
        if kind == "fault_sensor_stuck" and k >= ACT:
            frozen = row["LT101"] if frozen is None else frozen; row["LT101"] = frozen
        push(server, row); m.read(0, POLL_SPAN)
        if k == ACT:
            if kind == "benign_hmi_write":   other = ModbusClient(HMI);   other.write(REG["sp_level"], enc(55.0))
            if kind == "attack_rogue_write": other = ModbusClient(ROGUE); other.write(REG["sp_level"], enc(80.0))
            if kind == "attack_master_write": m.write(REG["sp_level"], enc(80.0))
            if kind == "attack_hmi_write":   other = ModbusClient(HMI);   other.write(REG["sp_level"], enc(80.0))
            if kind == "attack_recon":
                other = ModbusClient(ROGUE)
                for a in range(0, 60, 10): other.read(a, 10)
    m.close()
    if other: other.close()

KINDS = ["poll_only", "benign_hmi_write", "attack_rogue_write", "attack_master_write", "attack_hmi_write",
         "attack_gateway_spoof", "attack_recon", "fault_sensor_stuck"]
EXPECT = dict(poll_only=0, benign_hmi_write=0, attack_rogue_write=1, attack_master_write=1, attack_hmi_write=0,
              attack_gateway_spoof=0, attack_recon=1, fault_sensor_stuck=0)
REPS = int(os.environ.get("IDS_REPS", 10))

def run_all(server):
    windows = []
    for rep in range(REPS):
        for kind in KINDS:
            t0 = time.time(); scenario(kind, server); t1 = time.time()
            windows.append(dict(kind=kind, rep=rep, t0=t0, t1=t1)); time.sleep(0.25)
    return windows

# quick self-test of the protocol code (no IDS needed)
_srv = ModbusServer(); _srv.start(); time.sleep(0.2)
_c = ModbusClient(MASTER); _srv.regs[3] = 1234
assert _c.read(3, 1) == [1234]; _c.write(10, 5000); assert _srv.regs[10] == 5000
_c.write_many(20, [1, 2, 3]); assert _srv.regs[20:23] == [1, 2, 3]
_c.close(); _srv.stop(); print("modbus codec self-test OK on port", PORT)
""", tags=("part2",))

code(r"""
# ---- Install tools, capture, run Suricata (Colab: root) -----------------------------------------------------
SKIP_IDS = os.environ.get("SKIP_IDS") == "1"
IDS_DIR = RESULTS / "ids"; IDS_DIR.mkdir(exist_ok=True)
PCAP, RULES, LOGDIR = IDS_DIR / "modbus.pcap", IDS_DIR / "local.rules", IDS_DIR / "suricata_logs"
WINDOWS = None
if not SKIP_IDS:
    subprocess.run("apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq suricata tcpdump", shell=True, check=False)
    print(subprocess.run(["suricata", "-V"], capture_output=True, text=True).stdout.strip())
    RULES.write_text(
        f'alert tcp ![{MASTER},{HMI}] any -> any {PORT} (msg:"OT unauthorised client to Modbus port"; flow:to_server; sid:1000001; rev:1;)\n'
        f'alert modbus !{HMI} any -> any any (msg:"Modbus write from non-engineering host"; modbus: access write; sid:1000002; rev:1;)\n')
    srv = ModbusServer(); srv.start(); time.sleep(0.3)
    cap = subprocess.Popen(["tcpdump", "-i", "lo", "-U", "-w", str(PCAP), "tcp", "port", str(PORT)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.5)
    WINDOWS = run_all(srv)
    time.sleep(1.5); cap.terminate(); cap.wait(); srv.stop()
    print("captured", PCAP.stat().st_size, "bytes;", len(WINDOWS), "scenario runs")
    if LOGDIR.exists():
        import shutil; shutil.rmtree(LOGDIR)
    LOGDIR.mkdir()
    r = subprocess.run(["suricata", "-c", "/etc/suricata/suricata.yaml", "-r", str(PCAP), "-S", str(RULES), "-l", str(LOGDIR),
                        "-k", "none", "--set", "app-layer.protocols.modbus.enabled=yes"], capture_output=True, text=True)
    print("suricata exit code", r.returncode); print((r.stdout + r.stderr)[-1500:])
""", tags=("part2", "skip_local"))

code(r"""
# ---- Attribute alerts to scenario windows and compare with the pre-registered predictions ----------------------
if not SKIP_IDS:
    alerts = []
    eve = LOGDIR / "eve.json"
    for line in eve.read_text().splitlines():
        e = json.loads(line)
        if e.get("event_type") == "alert":
            ts = dt.datetime.strptime(e["timestamp"], "%Y-%m-%dT%H:%M:%S.%f%z").timestamp()
            alerts.append(dict(ts=ts, src=e.get("src_ip"), sid=e["alert"]["signature_id"], sig=e["alert"]["signature"]))
    print("total alerts in eve.json:", len(alerts), "| app-layer protocols seen:",
          sorted({json.loads(l).get("app_proto") for l in eve.read_text().splitlines() if '"app_proto"' in l} - {None}))
    rows = []
    for w in WINDOWS:
        hit = [a for a in alerts if w["t0"] - 0.02 <= a["ts"] <= w["t1"] + 0.05]
        rows.append(dict(kind=w["kind"], rep=w["rep"], alerted=len(hit) > 0, sids=sorted({a["sid"] for a in hit})))
    D = pd.DataFrame(rows)
    T = D.groupby("kind").agg(p_alert=("alerted", "mean"), n=("alerted", "size"))
    T["expected"] = pd.Series(EXPECT); T["matches"] = (T.p_alert.round(2) == T.expected)
    T["sids_seen"] = D.groupby("kind").sids.apply(lambda s: sorted({x for l in s for x in l}))
    print(T)
    if not T.matches.all():
        print("\nMISMATCH with predictions -> inspect rules / Suricata modbus parser before using these numbers:",
              list(T.index[~T.matches]))
    # translate to the 'p_ids by attack class' structure used in Notebook 05 (weights are MY assumptions - change them)
    W_ATTACKER = dict(attack_rogue_write=0.25, attack_master_write=0.10, attack_hmi_write=0.25, attack_gateway_spoof=0.30, attack_recon=0.10)
    p_ids = float(sum(W_ATTACKER[k] * T.loc[k, "p_alert"] for k in W_ATTACKER))
    out = dict(table=T.drop(columns=["sids_seen"]).reset_index().to_dict("records"), attacker_mix_weights=W_ATTACKER,
               implied_overall_p_ids=p_ids, benign_fp=float(T.loc["benign_hmi_write", "p_alert"]), reps=REPS,
               suricata_version=subprocess.run(["suricata", "-V"], capture_output=True, text=True).stdout.strip())
    json.dump(out, open(RESULTS / "part2_ids_empirical.json", "w"), indent=2)
    print(f"\nimplied overall p_ids under the assumed attacker mix = {p_ids:.2f}  (Notebook 05 assumed 0.5)")
else:
    print("SKIP_IDS=1 (local plumbing test): IDS analysis skipped")
""", tags=("part2", "skip_local"))
