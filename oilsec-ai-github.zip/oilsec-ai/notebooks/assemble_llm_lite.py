"""Standalone LITE Colab notebook for Part 1 v2 (free T4, ~25-35 min plan). Usage: python3 assemble_llm_lite.py"""
import json, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_colab_part3            # noqa: populates CELLS with parts 2-5 (cut off below)
from build_colab_part1 import CELLS

cut = next(i for i, (k, src, _) in enumerate(CELLS) if k == "markdown" and src.lstrip().startswith("---\n# Part 2"))
tail = list(CELLS[:cut])            # header md + setup + Part 1 cells (incl. the H-L8 comparison cell, which sits last)
tail = [c for c in tail if not (c[0] == "markdown" and "Colab companion notebook" in c[1])]

head = ("markdown", r"""
# OilSec-AI — Part 1 v2 **LITE** (real LLM investigator, free Colab T4)

Small-model, short-run version of the amended Part 1. Parts 2-4 are not needed again.
Everything concerns a *simulated* separator and *synthetic* provenance - nothing here supports claims about a real plant.

**Setup:** Runtime ▸ Change runtime type ▸ **T4 GPU**. Run the cells down to the **RUN SETTINGS** cell (upload `oilsec-ai.zip` when asked).

**Run plan (3 runs, each ~7-10 min; my estimate, not measured on your runtime). After each run: run the last cell (zip), then edit RUN SETTINGS and use *Runtime ▸ Run after* from that cell.**
| Run | MODEL_ID | OUTPUT_MODE | SPLIT | Purpose |
|---|---|---|---|---|
| 0 | Qwen/Qwen2.5-3B-Instruct | prefill | dev | sanity check of prompts/parsing on v1 seeds (prompt edits allowed **only here**) |
| 1 | Qwen/Qwen2.5-3B-Instruct | prefill | test | main result (frozen prompts) |
| 2 | Qwen/Qwen2.5-1.5B-Instruct | prefill | test | scale-down comparison |

Optional extras (only if time remains): `OUTPUT_MODE="raw"` on the test split (measures schema-following without prefill; v1 already showed 3B-raw fails on dev), `RUN_FREETEXT="1"` (adds ~8-10 min per run).
If the session disconnects, finished runs survive only if you downloaded their zip - so download after each run.
""", ())

settings = ("code", r"""
# ===== RUN SETTINGS - edit, then Runtime > Run after (from this cell) =========================================
import os
RUN = dict(MODEL_ID="Qwen/Qwen2.5-3B-Instruct",   # Qwen/Qwen2.5-1.5B-Instruct for run 2
           OUTPUT_MODE="prefill",                 # "prefill" | "raw"
           SPLIT="dev",                           # run 0: "dev"; runs 1-2: "test" (freeze prompts first!)
           RUN_FREETEXT="0")                      # "1" adds the free-text + extractor-control arms (slow)
if not os.environ.get("OILSEC_LOCAL_TEST"): os.environ.update(RUN)
print(RUN)
""", ("part1",))

pkg = ("code", r"""
import shutil, glob
_keep = RESULTS / "part1_v2_pkg"; _keep.mkdir(exist_ok=True)
for f in glob.glob(str(RESULTS / "part1_llm_*")):
    if "_v2_" in f: shutil.copy(f, _keep)
zip_path = shutil.make_archive(str(REPO / "part1_v2_results"), "zip", _keep)
print("created", zip_path, sorted(p.name for p in _keep.iterdir()))
if IN_COLAB:
    from google.colab import files
    files.download(zip_path)
""", ("part1", "skip_local"))

i_cfg = next(i for i, c in enumerate(tail) if c[0] == "code" and "# ---- Part 1 config" in c[1])
cmp_i = next(i for i, c in enumerate(tail) if c[0] == "code" and "H-L8 (descriptive)" in c[1])
cmp_cell = tail.pop(cmp_i)
cells_in = [head] + tail[:i_cfg] + [settings] + tail[i_cfg:] + [cmp_cell, pkg]
cells = []
for i, (kind, src, tags) in enumerate(cells_in):
    c = {"cell_type": kind, "metadata": {"id": f"c{i:02d}", "tags": list(tags)}, "source": src.strip("\n").splitlines(True)}
    if kind == "code": c.update(execution_count=None, outputs=[])
    cells.append(c)
nb = {"nbformat": 4, "nbformat_minor": 5, "cells": cells,
      "metadata": {"accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4", "name": "OilSec_AI_Part1_LLM_v2_lite.ipynb"},
                   "kernelspec": {"name": "python3", "display_name": "Python 3"}, "language_info": {"name": "python"}}}
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "OilSec_AI_Part1_LLM_v2_lite.ipynb")
json.dump(nb, open(out, "w"), indent=1); print("wrote", out, "cells:", len(cells))
