# Reproducing the paper's numbers

| Paper item | Command (from repo root) | Output |
|---|---|---|
| Unit tests (48) | `python3 -m unittest discover -s tests` | pass/fail |
| Simulator validation (§3) | `python3 experiments/exp01_simulator_validation.py` | `results/exp01_results.json` (~2 min, 1 CPU) |
| Detector baselines (§4) | `python3 experiments/exp02_collect.py 1` (then `3`, `5`), `python3 experiments/exp02_analyze.py` | `results/exp02_*` |
| Mutation checks | `python3 tests/mutation_check.py all` | pass/fail |
| LLM verdicts, claims, injection, IDS split (§6, Tables 4-6) | `python3 analysis/final_numbers.py` | `analysis/final_numbers.json` (identical to the archived file) |
| Per-model comparison table | `python3 analysis/all_models.py` | `analysis/paper_numbers.json` |
| 3B development check | `python3 analysis/dev3b.py` | stdout |
| Figures 2, 5, 6 | `cd paper && python3 make_figures.py` | `paper/figures/*` |

No GPU is needed for any of the above: the analysis scripts re-score archived generations with the notebook's own parser and verifier running a mock backend.

## Re-running the LLM experiment (needs a GPU)
Open `notebooks/OilSec_AI_Part1_LLM_v2_lite.ipynb` in Google Colab (T4), upload a zip of this repository when asked, then follow the run plan at the top of the notebook (dev sanity run, then test runs for 3B and 1.5B; 7B needs 4-bit). Greedy decoding makes reruns near-identical, but exact token streams can differ across library versions and GPUs.

## What is *not* in this repository
No real plant data, no real traffic beyond the small synthetic Modbus pcap in `results/colab_parts2_4/ids/`, no model weights (downloaded from Hugging Face at run time).
