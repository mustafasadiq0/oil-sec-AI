# Notebook 04 — Detection baselines: results, critique, decision

Protocol: Notebook 03 (written before detector code). Code: `oilsec/detect/`, `tests/test_detectors.py`.
Collection: `experiments/exp02_collect.py` -> `results/exp02_runs_L{1,3,5}.csv`. Pre-registered analysis:
`experiments/exp02_analyze.py` -> `results/exp02_analysis.json`. Exploratory: `experiments/exp02b_exploratory.py`
(modes auc / auchard / mismatch / fusion). Figure: `docs/figures/exp02_tpr_curves.png`.

## 1. Pre-registered verdicts

| ID | Result | Verdict |
|---|---|---|
| P1 false alarms, 60 held-out normal runs, x1 | 0/60 for all five detectors; exact 95% CI upper bound 6.0% | PASS on the point-estimate rule; the CI does NOT establish <=5% (n too small) |
| P2 twin vs others, weak set (120 paired runs) | TPR: D1 0.00, D2 0.28, D3 0.00, **D4 0.98**, D4m 0.33. McNemar one-sided, Holm: all p < 1e-25 | PASS (hypothesis supported at this operating point) |
| P3 no leakage; A2 == F2 | detector scores unchanged with non-OBSERVABLE columns removed (unit test); per-seed outcomes of A2 and F2 identical for all detectors at x1, x3, x5 | PASS |
| S1 robustness | see 3 | descriptive |
| S2 model error | D4 0.98 -> D4m 0.33 (78 vs 0 discordant pairs) | see 3 |

## 2. Defects found by questioning my own work (before trusting any number)
- **Mutation testing of detector code**: 9 injected bugs, 5 survived the first test suite (observer correction removed,
  persistence ignored, SP-envelope bound, rules limit, warm-up). Five tests added; all 9 now killed (20 detector tests).
- **A "failing" test was not a bug**: CUSUM false-alarmed on a normal run with a 12-run calibration. Diagnosis: CUSUM
  sustained-score maxima are heavy-tailed; 12 runs -> 5/40 held-out normals above threshold, 40 runs -> 0/40.
- **Process killed between tool calls**: the first background collection died silently and saved nothing; collection
  was rerun one noise level per call. Data and thresholds are deterministic, so no result is affected.

## 3. What the results do and do not show
1. **The twin's lead is real at this operating point but conditional on the twin being nearly exact.** Removing
   plant-gain/volume errors of 10% barely matters (TPR 0.95-0.99), but a 2x error in the valve time constant drops
   weak-attack TPR to 0.33. Causal check: the valve-consistency residual becomes noisy, the pooled max-score threshold
   rises from 2.4 to 22.7 and masks the weak A1/A5 signals. Removing valve residuals restores A1/A5 to 20/20 (threshold
   2.09) but loses weak A4 (0/20). **Design lesson: residual channels need separate thresholds, not one pooled threshold.**
2. **Inverse crime remains.** The twin uses the simulator's own equations. Tests of structural error (wrong model form,
   unmodelled dynamics) were not done. Results are an upper bound for twin methods.
3. **AUC against pure-normal negatives is misleading.** D3 had AUC 1.0 against quiet normal runs but 0.34 (below chance)
   against runs containing benign events: IsolationForest finds benign operations (slugs, setpoint changes) more
   anomalous than weak attacks. A threshold-free check confirms D3's failure is not just a harsh threshold.
4. **Physically consistent attacks are invisible to a consistency check.** A3 (setpoint tamper) at 60-65: D4 5%
   (AUC 0.56-0.68) while D2, D3, D4m detect 100% because the process reaches an unusual operating state. At 55 nobody
   detects it (<=5%): it equals the benign operator change B3 by construction. Detection needs authorisation/provenance.
5. **OR-fusion (D4|D3|D2), exploratory**: restores A3_60/65 to 100% with FPR 0% (x1) / 1.7% (x3, x5), but raises the
   alert rate on the benign operator change B3 to 55% (x1) from 5%. A trade-off, not a free win.
6. **A2 (freeze) and F2 (stuck sensor) give identical outputs**, so the twin flags 85-100% of both: it detects the
   anomaly but cannot say attack vs fault. F1 (stuck outlet flow meter, no process effect): D4 alerts 35% (x1) to 100% (x5).
7. **Recalibration is essential.** Thresholds frozen at x1 give false-alarm rates at x3/x5 of: D4 83%/100%,
   D2 25%/55%. Recalibrated FPR stayed <=1.7%.
8. **Noise erodes slow-ramp detection**: A5 -0.001 bar/s: D4 TPR 1.00 (x1), 0.85 (x3), 0.30 (x5).
9. **CUSUM alerts on a benign operator setpoint change in 50% of runs (x1)**; D1 rules detect only after large physical
   consequences (median delay 560-660 s for A4_5, A5_-0.01) versus 5-26 s for D4.

## 4. Threats to validity (updated)
- All twin conclusions rest on a near-exact model (see 3.2). No real data.
- Test seeds 3000-3019 are shared by every condition, so runs within a detector are clustered by background noise.
  The p-values (~1e-36) overstate independent evidence; the effect (118 vs 0 discordant pairs) is too large for this to
  change the verdict, but pooled CIs should be read as optimistic. Only 20 seeds per condition (5% granularity).
- "Detected" counts any alert onset in [t0, t_end+600], including recovery transients; applied equally to all detectors.
- Zero-training-alert thresholds from 40 runs; real false-alarm rate is uncertain (P1 CI upper 6%).
- Attack grids and the weak-set definition were chosen by me before data collection but are still my choices.
- Unfiltered PLC output noise (Notebook 02) probably contributes to the valve-residual fragility; not tested.
- Level, pressure and valve residuals are not independent in this plant; fault isolation is not attempted.

## 5. Protocol deviations log
- Analysis: none; criteria unchanged. Exploratory analyses are labelled and did not alter any verdict.
- Collector patched (per-level output files; frozen detectors refit deterministically) after the background-process failure.
- `dist_scale` option added to the simulator (default 1.0; regression test confirms no change).

## 6. Decision gate for Step 3
Detection baselines accepted as the substrate for investigation experiments, with these constraints:
1. Treat D4 performance as an upper bound; add a structural-mismatch twin before any claim about real plants.
2. Next design change to test (pre-register first): per-channel thresholds for residuals, and a PV filter on the PLC.
3. Authorisation/provenance data must be part of the evidence for A3-vs-B3 and A2-vs-F2; signal-only claims are impossible.
4. Any investigation component must be evaluated on hard negatives (benign events, faults), not pure-normal data.
