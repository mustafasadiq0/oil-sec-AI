# Notebook 01 — Process simulator: protocol (written BEFORE any simulator code was run)

## Question
Can a small, deterministic, stylised separator simulator serve as a valid substrate for the
OilSec-AI experiments? "Valid" is narrow here: numerically correct, reproducible, controlled
well enough that "normal" is a meaningful class, and attacks that actually have physical effect.
It is NOT claimed to be calibrated against a real facility (no real data exist).

## Design choices (each is an assumption to be challenged)
- Two-phase separator. States: liquid volume V, gas inventory n, temperature T, two valve positions.
- Two PI loops (level via liquid valve, pressure via gas valve), independent SIS trip, PSV relief.
- Attacks act on PLC *inputs/outputs* (sensor spoof, setpoint tamper, output force).
- Separate RNG streams (process / sensor / SIS) -> common random numbers for paired experiments.
- Tuning seeds: 0-9. Validation seeds: 100-129. Validation seeds are never used to tune.
  Any change made after looking at validation results is a *protocol deviation* and is logged below.

## Hypotheses and pre-registered acceptance criteria
| ID | Hypothesis | Pass criterion |
|---|---|---|
| V1 | Determinism | same seed+events -> bit-identical output; different seed -> different |
| V2 | Common random numbers | with vs without an event, all columns identical before event start; background inflow identical throughout |
| V3 | Equilibrium consistency | noise/disturbance off: max abs deviation of L,P from setpoints < 1e-6 over 1 h |
| V4 | Bookkeeping closure | liquid and gas balances close to < 1e-6 (logged integrals vs state change) |
| V5 | Numerical convergence | substeps 5 vs 50 on a 1 h run with slug: max dL < 0.05 pct-pt, max dP < 0.02 bar |
| V6 | Normal-operation control quality (30 validation seeds, 1 h) | level within SP+-5 >=99% of time; pressure within SP+-0.5 bar >=99%; zero SIS trips; zero PSV lifts; valves saturated <1% of time |
| V7 | Benign disturbances are survivable | slug(+40%,120 s), well switch(+20%), operator SP 50->55: no SIS trip in >=95% of seeds; level back within +-2 of SP within 1200 s (SP change: within +-1 of new SP within 900 s) |
| V8 | Each attack has physical impact | in >=90% of 30 paired seeds, impact metric exceeds the 99th percentile of normal-operation max deviation (from V6 runs). Scenarios failing this are reported as ineffective, not silently dropped |
| V9 | Sensor noise matches configuration | measured std within 5% of configured, noise-only run |

Impact metric: max over the run of |true level - SP| (level attacks) or |true pressure - SP|
(pressure attacks), or any SIS trip / PSV lift.

## Known threats to validity (to be revisited after results)
1. Stylised physics, no calibration data.
2. Attack model limited to PLC-visible manipulation.
3. Identical mechanism for a sensor fault and a sensor-freeze attack -> unavoidable label ambiguity.
4. Single plant, single process, 1 h runs: external validity is weak.

## Protocol deviations log
See Notebook 02, section 5 (no criteria changed; two implementation additions logged).
