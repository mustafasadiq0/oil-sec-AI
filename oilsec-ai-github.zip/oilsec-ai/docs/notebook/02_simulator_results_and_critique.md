# Notebook 02 — Simulator validation: results, critique, decision

Scripts: `tests/test_sim_core.py` (V1-V4), `experiments/exp01_simulator_validation.py` (V5-V9),
`experiments/exp01b_exploratory.py` (exploratory, NOT pre-registered).
Raw output: `results/exp01_results.json`, `results/exp01b_output.txt`. Figure: `docs/figures/exp01_scenarios.png`.

## 1. Pre-registered verdicts (criteria exactly as written in Notebook 01)

| ID | Result | Verdict |
|---|---|---|
| V1 determinism | bit-identical for same seed; differs for different seed | PASS |
| V2 common random numbers | identical before event; background inflow & unaffected sensor stream identical | PASS |
| V3 equilibrium | |dL|,|dP| < 1e-6 over 1 h | PASS |
| V4 closure | liquid + gas balances < 1e-6, incl. overflow and PSV-relief branches (after test fix, see 3) | PASS |
| V5 convergence (5 vs 50 substeps) | max dL = 0.00033 pct-pt, max dP = 0.00029 bar | PASS |
| V6 normal operation (30 seeds) | level and pressure in band 100% in all runs; 0 trips; 0 PSV lifts; 0% valve saturation | PASS |
| V7 benign disturbances | 0% SIS trips, 100% settled (slug, well switch, operator SP) | PASS |
| V8 attack impact (>=90% of 30 paired seeds) | A1 100%, A2 93%, A3 100%, A4 100%, A5 100% | PASS (see critique of A2) |
| V9 noise injection | all 7 channels within 1.4% of configured sigma | PASS |

## 2. What the passing result does NOT show (critique)

1. **Criteria were too lenient to be informative.** V6 allowed +-5 pct-pt; observed level sd is 0.17 and
   99th-percentile max deviation is ~0.6. V7 "settled in 0 s" for slug and well switch because the level never
   left the +-2 band. Passing these says "nothing is broken", not "the simulator is realistic".
2. **The impact metric cannot separate harm from ordinary operation.** Its threshold derives from a very quiet
   normal class, so benign events (slug, well switch, operator SP change) also score impact = 100%.
3. **A2 (level freeze) passes V8 by the letter but is practically harmless alone.** Exploratory data: median max
   deviation 1.75 pct-pt, no alarms, no trips, peak level 51.1%. It is NOT counted as a consequential attack.
4. **A2 and F2 are bit-identical in every SCADA-visible column** (differ only in label for 1800 steps).
   Any detector using only PLC-visible signals is *provably unable* to separate them. Research question 2
   (malicious vs legitimate) can only be answered with provenance/context, not signal alone.
5. **F1 is a working negative control**: process truth is bit-identical to the counterfactual. Its 3% "impact"
   is one run above an empirical 99th-percentile threshold built from the same 30 runs (expected artefact).
6. **Level attacks surface on the pressure channel first**: in A1/A4 the first SIS trip is high-pressure in
   22/30 and 26/30 seeds (rising liquid shrinks gas headspace). A level-only detector would miss the earliest signal.
7. **Attack severity is very uneven** (exploratory): A1 and A4 trip the SIS (availability 83% / 77%); A3 and A5
   reach alarms but rarely trip (availability ~99%). Detection difficulty will differ accordingly.

## 3. Defects found by questioning the tests themselves
Mutation testing (6 injected bugs): 3 survived the first test suite (overflow unaccounted, relief unaccounted,
anti-windup removed) because no test exercised those branches. Added `sis_enabled` switch (stress tests only),
two branch-exercising closure tests and an anti-windup test. All 6 mutants are now killed (11 tests pass).

## 4. Known limitations (not fixed; fixing after seeing validation results = unlogged deviation)
- No blanket gas / low-pressure protection: pressure falls to 4.4-7 bar after A1/A4 recovery, below the
  5 bar downstream pressure in some seeds; back-flow not modelled.
- PLC output has unfiltered noise: one-step sd of u_level_calc = 1.07% vs actual valve 0.14%. A real PLC would
  filter the PV. Detectors must not exploit this artefact.
- Normal class is very quiet (level sd 0.17) -> detection of large attacks will look trivially easy.
- Level and pressure share the same vessel volume; the coupling is real physics but also a simulator design choice.
- Gas side is isothermal; temperature has no effect on pressure.
- Observation timing: sensors read start-of-scan truth; `true_*` columns are end-of-scan (one-step offset).
- Stylised single plant, 1 h runs, no calibration data. Nothing here supports claims about real facilities.

## 5. Protocol deviations log
- Criteria: none changed. No parameter tuned (controller worked as initially specified on tuning seeds 0-9).
- Code additions after first test run (tests re-run, criteria untouched): `sis_enabled` flag; logging of
  `true_zl`, `true_zp` (needed for V9).
- Exploratory analysis (Exp01b) is labelled exploratory and did not alter any verdict above.

## 6. Decision gate
Simulator accepted as a *conditionally valid* substrate for relative (comparative) detection experiments only.
Conditions that Step 2 must satisfy:
1. Attack-intensity sweeps (offset/ramp/setpoint magnitude) so detector differences are not hidden by saturation.
2. Disturbance-noise scaling (x1, x3, x5) as a robustness axis for the over-quiet normal class.
3. A2/F2 reported as a signal-indistinguishable pair; no claim of separating them from telemetry alone.
4. Detectors may use only `OBSERVABLE` columns; `true_*`/`truth_*` are for scoring only (leakage test required).
5. Thresholds fitted on training seeds only; scoring on held-out seeds (new range, e.g. 2000+).
