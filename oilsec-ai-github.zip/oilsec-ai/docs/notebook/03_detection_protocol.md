# Notebook 03 — Detection baselines: protocol (written BEFORE any detector code existed)

## Question
On this simulator, does a physics-consistency ("digital twin residual") detector detect weak attacks that
(i) static alarm rules, (ii) univariate CUSUM and (iii) an unsupervised multivariate ML detector miss —
at an equal, pre-set false-alarm budget — and how does that conclusion change with process-noise level and
twin model error?

## Detectors (all see ONLY `OBSERVABLE` columns, enforced structurally by the base class)
| ID | Detector | Fitted? |
|---|---|---|
| D1 | Static alarm rules: LT101 >70 or <30; PT101 >18 or <12 | no (fixed limits) |
| D2 | Two-sided CUSUM (k = 0.5 sd) on 9 standardised channels, score = max over channels | mean/sd from training |
| D3 | IsolationForest (100 trees, seed 0) on 60 s rolling mean/std/slope of 9 channels + SP registers, scored every 5 s | training |
| D4 | Twin residuals: level observer, gas-inventory observer, valve-lag consistency (x2), SP engineering envelope (level SP outside [35,65] or pressure SP outside [12,18]) | residual scales from training |
| D4m | D4 with a MISMATCHED model: kg x1.1, gor x0.9, v_total x1.1, valve tau x2 | same |

Fixed design constants (set now, not tuned on test data): observer gain K = 0.005 /s, persistence = 5 s,
warm-up = 120 s ignored, window of IF features = 60 s.
Operating point rule (identical for D2-D4m): threshold = maximum, over all training runs, of the sustained
score (rolling-min over the persistence window) -> zero alerts on the training set. D1 uses its fixed limits.

## Data
- Training: seeds 2000-2039 (20 pure normal + 20 with one random benign event), per noise level, 3600 s.
- Test: seeds 3000-3019 (20 per condition) for event conditions; seeds 3000-3059 (60) for pure-normal FPR.
  Seeds never overlap training (2000s) or Step-1 tuning/validation (0-9, 100-129, 1000-1199).
- Event at t0 = 900 s; run length 3600 s. Detection window = [t0, t_end + 600] (to run end if permanent).
- Process-disturbance scale (OU sigmas) x1, x3, x5. PRIMARY protocol: thresholds recalibrated on training
  data at the same noise level. SECONDARY: thresholds frozen from x1.

## Conditions (intensity sweeps; attack = positive class)
A1 level-sensor offset {-1,-2,-4,-8,-16,-35} · A3 level SP tamper {55,60,65,70,80} ·
A4 level-valve force {45,40,30,20,10,5} · A5 pressure ramp {-0.0005,-0.001,-0.002,-0.005,-0.01} bar/s ·
A2 level freeze · A2c freeze + well switch(+20%) at t0+60 ·
benign: B1 slug, B2 well switch, B3 operator SP 55 · faults: F1 FT102 stuck, F2 LT101 stuck.

## Hypotheses / pre-registered endpoints
| ID | Statement | Decision rule |
|---|---|---|
| P1 | Calibrated detectors keep run-level false alarms low on held-out normal runs (x1) | point estimate <= 5% for every detector; report exact 95% CI |
| P2 | D4 detects weak attacks better than each of D1, D2, D3 | Weak set = two weakest levels of A1, A4, A5 (6 conditions x 20 seeds = 120 paired runs, x1, recalibrated). One-sided exact McNemar, D4 vs each, Holm alpha=0.05. Rejected if not significant |
| P3 | No ground-truth leakage; A2 and F2 alerts identical | detector outputs identical with all non-OBSERVABLE columns removed; per-seed alert series for A2 vs F2 bit-identical for every detector |
| S1 | Robustness (descriptive) | TPR vs intensity per detector and noise level; FPR of frozen-x1 thresholds at x3/x5 |
| S2 | Model-error sensitivity (descriptive) | D4 vs D4m TPR on the weak set; paired |
| S3 | Detection delay (descriptive) | median delay per detector/condition, detected runs only |
| S4 | Benign/fault alert rates | alert rate in detection window for B1-B3, F1-F2 |

## Pre-declared threats to validity (to be checked after results)
1. **Inverse crime**: D4 uses the same equations (even the same valve-lag form) as the simulator; D4m only
   perturbs parameters and valve tau, not structure. D4's performance is an upper bound for twin methods.
2. D4 uses plant parameters (kg, gor, v_total) a real operator may not know accurately.
3. Zero-training-alert thresholds from 40 runs give an uncertain real false-alarm rate.
4. Over-quiet normal class (Notebook 02): addressed only through the x3/x5 noise sweep.
5. A3 SP=55 equals the benign operator change B3: indistinguishable by design -> expected failure.
6. Attack sweeps were chosen by me; detection boundaries depend on those grids.
7. Unfiltered PLC output noise (Notebook 02) may favour detectors that use u_calc.

## Protocol deviations log
See Notebook 04, section 5 (analysis criteria unchanged; collector patched for per-level output; dist_scale added).
