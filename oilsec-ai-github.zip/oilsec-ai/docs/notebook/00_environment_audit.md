# Notebook 00 — Environment audit

Date: 2026-11-01. Method: direct probing of the execution sandbox (not assumption).

| Item | Finding | Consequence |
|---|---|---|
| CPU / RAM | 1 core, 3.9 GB | Experiments must be small; no large deep models |
| GPU | none | No local LLM, no PyTorch training |
| Network | disabled (pip failed) | No new packages, no model download, no external API |
| Docker, Zeek, Suricata, Mosquitto, PostgreSQL, Redis | absent | Cannot run the original stack |
| Python libs | numpy, pandas, scipy, sklearn, networkx, matplotlib, yaml, joblib | Enough for simulation, classical ML, statistics |
| Missing | torch, fastapi, pytest, statsmodels | Use `unittest`, stdlib `sqlite3`, scipy |

## Decision
Everything claimed in this repository is a claim about a *stylised simulator*, not about a real
oil and gas facility, and not about Zeek / Suricata / OpenPLC / LLMs unless explicitly tested.
Components that cannot be executed here are specified, not simulated-as-if-real.
