# Notebook 06 — LLM investigator: v1 failure diagnosis and v2 amendment

Written AFTER seeing the v1 Colab results (Qwen2.5-3B-Instruct, 54 episodes, seeds 6000-6005). v1 outputs are archived in
`results/llm_v1_qwen2.5-3b/` and are now the DEV split. Replay: `python3 experiments/llm_v1_replay_diagnosis.py`.

## 1. Diagnosis (measured on the raw generations)
| Finding | Evidence |
|---|---|
| Model never emits the top-level object | `verdict` key present in 1/54 (ctx), 8/54 (signal); outputs begin `{` then bare claim objects + flat `rationale` |
| Parser tolerance alone cannot recover v1 | v2 tolerant parser: signal/ctx/forged 0/54 -> 0/54 valid (inject 4 -> 5). No verdict exists to recover and none is invented |
| Free text truncated | VERDICT line present in 30/54; model restates every evidence item and hits the 450-token cap |
| Free-text extractor returned nothing | >=1 claim in 6/54 |
| **Harness defect** in the control | extractor cites `"[E9]"`, lower-cases metrics; exact-match verifier -> 521/521 (100%) "unsupported". After normalising cite brackets and metric case: 31/521 = 6.0% |
| Residual 6.0% are genuine model errors | 29 = metric attached to the wrong evidence id (e.g. `fired_D1` cited as E3 which is `fired_D2`); 2 = impossible value (1.4e12) |
| H-L3 vacuous pass | denominator 0 valid episodes; v2 reports UNDEFINED when n < 10 |

Reading: v1's H-L1 failure is a genuine property of a 3B model under this prompt; its H-L2/H-L5/H-L6 values are not evidence about
faithfulness or injection robustness (NaN / harness-invalid).

## 2. v2 changes (frozen before any TEST-split run)
Prefill of the assistant turn (`{"verdict": "`), syntax-only tolerant parser, harness-side claim normalisation (strict counts still reported),
free-text prompt with VERDICT first / <=6 sentences / <=5 cited items and 700-token cap, extractor toy example + prefill, UNDEFINED guards,
LITE model ladder 1.5B and 3B (same family, fp16), 10 fresh seeds (7000+) - see section 5. Hypotheses H-L1..H-L7 and decision rules unchanged; H-L8 added (descriptive).

## 3. Threats / what v2 will and will not show
- Under `prefill`, schema validity is largely **by construction**: report `raw` and `prefill` separately; only `raw` measures schema-following skill.
- The normaliser is applied to all arms equally, but it is a post-hoc harness change; strict counts are in the output for comparison.
- 4-bit quantisation is a confound vs the fp16 3B of v1. Same family isolates scale, not architecture.
- Synthetic provenance, single prompt wording, greedy decoding, shared seeds across conditions (clustered), N small for interval estimates.
- Dev split is for prompt/parser iteration only. Once `SPLIT=test` has been run, a prompt change is a new deviation and must be logged; do not iterate on test.

## 4. Protocol deviations log
- v1 -> v2: all items in section 2. Reason: v1 failure mode and harness defect found by inspection of v1 outputs.
- No v2 model has been run on real weights as of this note; only plumbing (mock backend) and the v1 replay were executed.

## 5. LITE configuration (free Colab T4) - added after the first v2 build proved too heavy
Reason: the 7B/14B 4-bit plan did not fit the user's free-Colab budget. Changes, all before any TEST-split run:
- Models: Qwen2.5-1.5B-Instruct and Qwen2.5-3B-Instruct, fp16, no quantisation (removes the 4-bit confound of section 3).
- N_SEEDS = 10 (test) / 4 (dev); MAX_NEW 380; batch 12.
- forged/inject arms regenerate only episodes whose prompt differs from the ctx prompt; identical prompts reuse the ctx output
  (JSON-arm generations 53 instead of 72 per 18 episodes in the mock run).
- Free-text + extractor-control arms OFF by default (`RUN_FREETEXT=1` enables). H-L6 is then reported `SKIPPED`; the harness-fix
  validation of the control extractor therefore rests on the v1 replay (section 1), not on a v2 run, unless the arm is enabled.
- Planned runs: dev sanity (3B prefill) -> test 3B prefill -> test 1.5B prefill. Time estimate ~25-35 min total (not measured on a real T4).
- Power: ~110 runs x ~0.8 coverage = ~90 episodes; ~8 per condition. Only gross failures are detectable; Wilson intervals will be wide.
