# Notebook 05 — Triage / investigation layer: protocol (written BEFORE any triage code existed)

## Question
Given an alert, can an evidence-based triage layer (a) classify the cause as attack / benign / fault,
(b) say how much extra provenance context (change tickets, maintenance tickets, IDS hits) is worth,
and (c) can its written findings be mechanically checked against the evidence?

## What is and is NOT being tested
- No LLM is available in this sandbox. The "investigator" is a deterministic template generator. Nothing here
  measures LLM quality, reasoning or hallucination rate on free text. What IS tested: whether the evidence package
  contains enough information to separate causes, and whether a structured-claim verifier catches
  injected false claims.
- Provenance signals are SYNTHETIC and generated from MY assumed reliabilities (table below). Results are
  conditional statements ("if IDS catches p% of attacks ..."), reported as curves, never as one accuracy.

## Unit of analysis
Per run, the FIRST alert episode starting in the detection window [t0, t_end+600]. Alerts come from the
fusion OR(D1,D2,D3,D4) of the existing pre-registered detectors (exact D4, noise x1). Episodes merge alert gaps <= 60 s.
Triage happens W = 120 s after episode onset and may use only data up to onset+120 s. Runs with no alert are
excluded from triage and reported as coverage loss.

## Evidence package (all signal features from OBSERVABLE columns only)
Detector fired flags + lags (D1-D4); twin residual peaks per channel (level, gas, valve_l, valve_p, sp-envelope);
SP register deltas; LT/PT deltas; flatness (std) of LT101, PT101, FT101, FT102; valve-vs-command gaps; SIS flag.
Context (synthetic): change_ticket, maint_ticket, ids_alert.

## Synthetic context model (assumptions, all swept or reported)
| Source | Rule |
|---|---|
| change_ticket | benign B3: p=0.9; B2: p=0.5; B1: 0; faults: 0; attack A3: forged with prob q_forge (default 0.1); other attacks 0 |
| maint_ticket | fault: p=0.3; otherwise 0 |
| ids_alert | attack: p_ids (default 0.5); benign/fault: 0.05 |
Sweeps: p_ids in {0,.25,.5,.75,1}, q_forge in {0,.1,.25,.5}.

## Data and model
Triage-training seeds 4000-4019, test seeds 3000-3019 (conditions as in Notebook 03, noise x1), plus normal runs
3000-3059 for alert-episode false alarms. Classifier: RandomForest (300 trees, seed 0, class_weight balanced),
fixed in advance, no model selection on test data. Classes: attack / benign / fault.

## Hypotheses and decision rules
| ID | Statement | Decision rule |
|---|---|---|
| H3.1 | Leakage / ambiguity sanity: with signal-only features, A2 and F2 episodes get identical predictions per seed | must hold exactly |
| H3.2 | Context helps at default reliability | macro-F1(signal+ctx) - macro-F1(signal-only) has 95% seed-cluster bootstrap CI (2000 resamples) with lower bound > 0 |
| H3.3 | Value of information is monotone in IDS reliability and degrades with forged tickets | Spearman(p_ids, macro-F1) >= 0.8 at q_forge=0.1; recall on A3_55 at q_forge=0.5 < recall at q_forge=0 |
| H3.4 | Claim verifier is effective | for 5 injected corruption types: recall >= 0.95 each, false rejection of clean reports <= 2%; AND removing each check drops its own type's recall below 0.5 (no dead checks) |
| H3.5 | Generalisation to unseen attack families (descriptive) | leave-one-family-out attack recall; expectation: at least one family < 0.5 |
| H3.6 | Forged-ticket shift (descriptive) | train at q=0.1, test at q=0.5: A3 attack recall change vs matched training |

## Pre-declared threats to validity
1. Circularity: provenance generated from labels; only trends vs reliability are interpretable.
2. Features were designed by me knowing the attack families (e.g. flatness for frozen sensors); LOFO tests partly address this.
3. Class balance is an artefact of my condition grid (24 attack, 3 benign, 2 fault conditions); macro metrics and balanced weights used.
4. First-episode unit ignores multi-episode incidents and overlapping events.
5. Verifier works on structured claims; free-text claim extraction (the hard part for an LLM) is not tested.
6. Only noise x1 and one plant; 20 test seeds shared across conditions (clustered).
7. Alert source is fusion OR, which already raised benign-event alert rates (Notebook 04): triage sees many benign episodes by design.

## Protocol deviations log
(none yet)
