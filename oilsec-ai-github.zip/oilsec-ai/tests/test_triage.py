import unittest
import numpy as np
import pandas as pd

from oilsec.sim.runner import simulate, SimConfig, OBSERVABLE
from oilsec.sim import scenarios as sc
from oilsec.sim.scenarios import Event
from oilsec.detect.twin import Twin
from oilsec.triage.evidence import (find_episodes, first_episode, signal_features, make_context, ContextParams,
                                    evidence_items, SIGNAL_COLS, CTX_COLS, W, DETS)
from oilsec.triage.report import (generate_report, verify, corrupt, CORRUPTIONS, OWNER, ALL_CHECKS)
from oilsec.triage.classify import fit_predict_proba, CLASSES, cluster_bootstrap_delta, macro_f1


def run(seed=3000, events=()):
    return simulate(SimConfig(seed=seed, duration_s=2400, events=tuple(events)))


class TestEpisodes(unittest.TestCase):
    def test_merge_gap(self):
        a = np.zeros(400, bool); a[10:13] = True; a[50:53] = True; a[200:202] = True
        self.assertEqual(find_episodes(a), [(10, 52), (200, 201)])
        self.assertEqual(find_episodes(np.zeros(5, bool)), [])

    def test_first_episode_window(self):
        eps = [(10, 20), (300, 310), (900, 950)]
        self.assertEqual(first_episode(eps, 250, 1000), (300, 310))
        self.assertIsNone(first_episode(eps, 960, 1000))


class TestCausality(unittest.TestCase):
    def setUp(self):
        self.df = run(events=[sc.attack_valve_force(900)])
        n = len(self.df)
        self.alerts = {d: np.zeros(n, bool) for d in DETS}
        self.ch = np.zeros((n, 5))

    def test_features_ignore_future_beyond_window(self):
        onset = 1000
        f0 = signal_features(self.df, onset, self.alerts, self.ch)
        d2 = self.df.copy()
        for c in OBSERVABLE:
            d2.loc[onset + W:, c] = 1e6
        al2 = {k: v.copy() for k, v in self.alerts.items()}
        for k in al2: al2[k][onset + W:] = True
        ch2 = self.ch.copy(); ch2[onset + W:] = 1e6
        f1 = signal_features(d2, onset, al2, ch2)
        self.assertEqual(f0, f1)

    def test_features_do_depend_on_window(self):
        onset = 1000
        f0 = signal_features(self.df, onset, self.alerts, self.ch)
        d2 = self.df.copy(); d2.loc[onset:onset + 50, "LT101"] = 500.0
        f1 = signal_features(d2, onset, self.alerts, self.ch)
        self.assertNotEqual(f0["std_LT101"], f1["std_LT101"])


class TestContext(unittest.TestCase):
    def test_monotone_coupling(self):
        for s in range(3000, 3040):
            lo = make_context("A1_-2", "attack", s, ContextParams(p_ids=0.25))["ids_alert"]
            hi = make_context("A1_-2", "attack", s, ContextParams(p_ids=0.75))["ids_alert"]
            self.assertLessEqual(lo, hi)
            a = make_context("A3_55", "attack", s, ContextParams(q_forge=0.1))["change_ticket"]
            b = make_context("A3_55", "attack", s, ContextParams(q_forge=0.5))["change_ticket"]
            self.assertLessEqual(a, b)

    def test_rates_match_parameters(self):
        n = 4000
        t = np.mean([make_context("B3", "benign", s)["change_ticket"] for s in range(n)])
        i = np.mean([make_context("A4_5", "attack", s)["ids_alert"] for s in range(n)])
        self.assertAlmostEqual(t, 0.9, delta=0.03); self.assertAlmostEqual(i, 0.5, delta=0.03)

    def test_only_expected_sources(self):
        for s in range(200):
            self.assertEqual(make_context("A4_5", "attack", s)["change_ticket"], 0.0)
            self.assertEqual(make_context("F1", "fault", s)["change_ticket"], 0.0)
            self.assertEqual(make_context("B1", "benign", s)["maint_ticket"], 0.0)


def _feat(**over):
    f = {k: 0.0 for k in SIGNAL_COLS + CTX_COLS}
    f.update(res_level=3.2, res_gas=1.1, res_valve_l=0.4, res_valve_p=0.2, fired_D4=1.0, d_sp_level=5.0, d_lt=-3.0,
            d_pt=0.5, std_LT101=0.0, std_PT101=0.03, std_FT101=0.8, std_FT102=0.8, change_ticket=1.0)
    f.update(over); return f


class TestVerifier(unittest.TestCase):
    P = np.array([0.7, 0.2, 0.1])          # moderate confidence -> overconfidence is applicable

    def setUp(self):
        self.items = evidence_items(_feat())
        self.rep = generate_report(self.items, self.P)

    def test_clean_report_passes(self):
        self.assertEqual(verify(self.rep, self.items, self.P), [])

    def test_report_contains_every_claim_type(self):
        types = {c["type"] for c in self.rep["claims"]}
        self.assertEqual(types, {"numeric", "direction", "verdict"})

    def test_each_corruption_is_caught_by_its_owner_check(self):
        rng = np.random.default_rng(0)
        for k in CORRUPTIONS:
            for _ in range(30):
                bad = corrupt(self.rep, k, rng, self.P)
                self.assertIsNotNone(bad, k)
                v = verify(bad, self.items, self.P)
                self.assertIn(OWNER[k], {x[1] for x in v}, k)

    def test_ablating_owner_check_removes_detection(self):
        rng = np.random.default_rng(1)
        for k in CORRUPTIONS:
            rest = tuple(c for c in ALL_CHECKS if c != OWNER[k])
            for _ in range(30):
                bad = corrupt(self.rep, k, rng, self.P)
                self.assertEqual(verify(bad, self.items, self.P, checks=rest), [], k)

    def test_overconfidence_not_applicable_when_sure(self):
        self.assertIsNone(corrupt(self.rep, "overconfidence", np.random.default_rng(0), np.array([0.95, 0.03, 0.02])))


class TestTwinChannels(unittest.TestCase):
    def test_channel_max_equals_score_when_sp_ok(self):
        tr = [run(s) for s in range(2000, 2006)]
        tw = Twin().fit(tr)
        df = run(3000, [sc.attack_valve_force(900, value=40.0)])
        ch = tw.channel_scores(df); sc_ = tw.score(df)
        ok = ch[:, 4] == 0
        np.testing.assert_allclose(ch[ok, :4].max(axis=1)[120:], sc_[ok][120:])


class TestTwinSpFlag(unittest.TestCase):
    def test_sp_flag_set_only_when_outside_envelope(self):
        tw = Twin().fit([run(s) for s in range(2000, 2004)])
        self.assertEqual(tw.channel_scores(run(3000))[:, 4].max(), 0.0)
        ch = tw.channel_scores(run(3000, [sc.attack_setpoint_tamper(900, value=80.0)]))
        self.assertEqual(ch[:900, 4].max(), 0.0); self.assertEqual(ch[905:, 4].min(), 1.0)
        ch = tw.channel_scores(run(3000, [sc.operator_setpoint(900, value=55.0)]))
        self.assertEqual(ch[:, 4].max(), 0.0)
        low = Event("S", "setpoint_change", "attack", 900, None, {"loop": "level", "value": 30.0, "authorised": False})
        self.assertEqual(tw.channel_scores(run(3000, [low]))[905:, 4].min(), 1.0)   # lower bound is 35
        low = [sc.Event("L", "setpoint_change", "attack", 900, None, {"loop": "level", "value": 30.0, "authorised": False})]
        self.assertEqual(tw.channel_scores(run(3000, low))[905:, 4].min(), 1.0)


class TestClassifier(unittest.TestCase):
    def test_shapes_and_bootstrap(self):
        rng = np.random.default_rng(0)
        def mk(n):
            d = pd.DataFrame(rng.normal(size=(n, len(SIGNAL_COLS) + len(CTX_COLS))), columns=SIGNAL_COLS + CTX_COLS)
            d["cls"] = rng.choice(CLASSES, n); d["seed"] = rng.integers(0, 10, n); return d
        tr, te = mk(120), mk(60)
        P = fit_predict_proba(tr, te, use_ctx=True)
        self.assertEqual(P.shape, (60, 3)); np.testing.assert_allclose(P.sum(axis=1), 1.0, atol=1e-9)
        pred = np.array(CLASSES)[P.argmax(1)]
        lo, hi, m = cluster_bootstrap_delta(te, pred, pred, n_boot=50)
        self.assertEqual((lo, hi), (0.0, 0.0))


if __name__ == "__main__":
    unittest.main()
