import unittest
import numpy as np
import pandas as pd

from oilsec.sim.runner import simulate, SimConfig, OBSERVABLE
from oilsec.sim import scenarios as sc
from oilsec.detect.base import Detector, sustained, WARMUP
from oilsec.sim.scenarios import Event
from oilsec.detect.rules import AlarmRules
from oilsec.detect.cusum import Cusum
from oilsec.detect.iforest import IForest
from oilsec.detect.twin import Twin

T0 = 900
TRAIN = None
DET = {}


def sim(seed, events=(), **kw):
    return simulate(SimConfig(seed=seed, duration_s=2400, events=tuple(events), **kw))


def setUpModule():
    global TRAIN
    TRAIN = [sim(s) for s in range(2000, 2012)]
    for d in (AlarmRules(), Cusum(), IForest(), Twin()):
        DET[d.name] = d.fit(TRAIN)
    DET["twin_no_valve_l"] = Twin(use=("level", "gas", "valve_p", "sp"), name="x1").fit(TRAIN)
    DET["twin_no_level_gas"] = Twin(use=("valve_l", "valve_p", "sp"), name="x2").fit(TRAIN)
    DET["twin_no_gas"] = Twin(use=("level", "valve_l", "valve_p", "sp"), name="x3").fit(TRAIN)
    DET["twin_no_sp"] = Twin(use=("level", "gas", "valve_l", "valve_p"), name="x4").fit(TRAIN)


def delay(det, df, t0=T0):
    a = det.alerts(df)
    a[:t0] = False
    return None if not a.any() else int(np.argmax(a)) - t0


class TestLeakage(unittest.TestCase):
    def test_guard_blocks_peeking_detector(self):
        class Peeker(Detector):
            name = "peek"
            def _score(self, o): return o["true_level"].values   # must raise
        with self.assertRaises(KeyError):
            Peeker().score(sim(1, dur=600) if False else sim(1))

    def test_scores_identical_with_nonobservable_columns_removed(self):
        df = sim(3000, [sc.attack_valve_force(T0)])
        stripped = df[OBSERVABLE].copy()
        for name in ("D1_rules", "D2_cusum", "D3_iforest", "D4_twin"):
            np.testing.assert_array_equal(DET[name].score(df), DET[name].score(stripped), err_msg=name)

    def test_attack_and_fault_with_same_signature_give_identical_alerts(self):
        a = sim(3001, [sc.attack_level_freeze(T0)]); f = sim(3001, [sc.sensor_fault_stuck_level(T0)])
        for name in ("D1_rules", "D2_cusum", "D3_iforest", "D4_twin"):
            np.testing.assert_array_equal(DET[name].alerts(a), DET[name].alerts(f), err_msg=name)


class TestTextbookDetections(unittest.TestCase):
    def test_no_alarm_on_normal_for_rules_and_twin(self):
        # CUSUM/IF excluded on purpose: with a 12-run calibration their false-alarm rate is a statistical
        # property (see Notebook 04), measured in Exp02 endpoint P1, not a code-correctness property.
        for s in (3000, 3001, 3002):
            df = sim(s)
            for name in ("D1_rules", "D4_twin"):
                self.assertFalse(DET[name].alerts(df).any(), f"{name} alarmed on normal seed {s}")

    def test_rules_detect_gross_level_spoof(self):
        self.assertIsNotNone(delay(DET["D1_rules"], sim(3000, [sc.attack_level_spoof(T0)])))

    def test_rules_miss_small_spoof(self):
        self.assertIsNone(delay(DET["D1_rules"], sim(3000, [sc.attack_level_spoof(T0, offset=-2)])))

    def test_twin_detects_small_level_spoof_fast(self):
        d = delay(DET["D4_twin"], sim(3000, [sc.attack_level_spoof(T0, offset=-2)]))
        self.assertIsNotNone(d); self.assertLessEqual(d, 30)

    def test_twin_detects_valve_force_fast(self):
        d = delay(DET["D4_twin"], sim(3000, [sc.attack_valve_force(T0, value=40.0)]))
        self.assertIsNotNone(d); self.assertLessEqual(d, 30)

    def test_twin_detects_pressure_ramp(self):
        d = delay(DET["D4_twin"], sim(3000, [sc.attack_pressure_ramp(T0)]))
        self.assertIsNotNone(d); self.assertLessEqual(d, 90)

    def test_twin_detects_sp_tamper_via_envelope(self):
        d = delay(DET["D4_twin"], sim(3000, [sc.attack_setpoint_tamper(T0)]))
        self.assertIsNotNone(d); self.assertLessEqual(d, 10)


class TestAblationSensitivity(unittest.TestCase):
    """Each twin component must be necessary for its own textbook case (guards against dead code)."""

    def test_valve_residual_needed_for_valve_force(self):
        df = sim(3000, [sc.attack_valve_force(T0, value=40.0)])
        full = delay(DET["D4_twin"], df)
        abl = delay(DET["twin_no_valve_l"], df)
        self.assertLessEqual(full, 30); self.assertTrue(abl is None or abl > 60)

    def test_level_and_gas_observers_needed_for_sensor_spoof(self):
        df = sim(3000, [sc.attack_level_spoof(T0, offset=-8.0)])
        abl = delay(DET["twin_no_level_gas"], df)
        self.assertTrue(abl is None or abl > 60)

    def test_gas_observer_needed_for_pressure_ramp(self):
        df = sim(3000, [sc.attack_pressure_ramp(T0)])
        abl = delay(DET["twin_no_gas"], df)
        self.assertTrue(abl is None or abl > 120)

    def test_sp_envelope_needed_for_sp_tamper_speed(self):
        df = sim(3000, [sc.attack_setpoint_tamper(T0)])
        abl = delay(DET["twin_no_sp"], df)
        self.assertTrue(abl is None or abl > 30)


class TestBaseMechanics(unittest.TestCase):
    def test_persistence_requires_five_consecutive_samples(self):
        x = np.zeros(30); x[10:14] = 5.0          # 4 samples: must NOT alert at thr 1
        self.assertFalse((sustained(x) > 1.0).any())
        x[10:15] = 5.0                            # 5 samples: must alert
        self.assertTrue((sustained(x) > 1.0).any())

    def test_warmup_zeroes_scores_for_all_detectors(self):
        df = sim(3000).copy(); df.loc[:50, "LT101"] = 90.0       # anomalous inside warm-up
        for name in ("D1_rules", "D2_cusum", "D3_iforest", "D4_twin"):
            self.assertTrue((DET[name].score(df)[:WARMUP] == 0.0).all(), name)


class TestRulesLimits(unittest.TestCase):
    def test_level_limit_is_70(self):
        df = sim(3000).copy(); df.loc[1000:1019, "LT101"] = 72.0
        self.assertTrue(DET["D1_rules"].alerts(df)[1000:1030].any())
        df = sim(3000).copy(); df.loc[1000:1019, "LT101"] = 68.0
        self.assertFalse(DET["D1_rules"].alerts(df).any())


class TestTwinSpEnvelope(unittest.TestCase):
    def _sp(self, v): return [Event("S", "setpoint_change", "attack", T0, None, {"loop": "level", "value": v, "authorised": False})]

    def test_low_setpoint_outside_envelope_flagged(self):
        d = delay(DET["D4_twin"], sim(3000, self._sp(30.0)))
        self.assertIsNotNone(d); self.assertLessEqual(d, 10)

    def _psp(self, v): return [Event("P", "setpoint_change", "attack", T0, None, {"loop": "pressure", "value": v, "authorised": False})]

    def test_pressure_setpoint_bounds(self):
        for v in (20.0, 10.0):                        # above 18 and below 12
            d = delay(DET["D4_twin"], sim(3000, self._psp(v)))
            self.assertIsNotNone(d, v); self.assertLessEqual(d, 10, v)
        d = delay(DET["D4_twin"], sim(3000, self._psp(16.0)))      # inside envelope
        self.assertTrue(d is None or d > 60)

    def test_setpoint_inside_envelope_not_flagged_immediately(self):
        d = delay(DET["D4_twin"], sim(3000, self._sp(55.0)))
        self.assertTrue(d is None or d > 60)


class TestGasObserverConverges(unittest.TestCase):
    def test_mean_rms_gas_residual_small_on_normal_runs(self):
        det = DET["D4_twin"]; rms = []
        for sd in range(3000, 3010):
            o = sim(sd)[OBSERVABLE]
            rms.append(np.sqrt(np.mean(det.residuals(o)[1][120:] ** 2)))
        self.assertLess(float(np.mean(rms)), 0.09)     # intact 0.063; observer-correction removed 0.122


if __name__ == "__main__":
    unittest.main()
