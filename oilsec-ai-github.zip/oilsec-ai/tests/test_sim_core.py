import unittest
import numpy as np
import pandas as pd

from oilsec.sim.runner import simulate, SimConfig, OBSERVABLE
from oilsec.sim import scenarios as sc
from oilsec.sim.process import PlantParams, PI
from oilsec.sim.scenarios import Event


def run(seed=0, dur=3600, events=(), **kw):
    return simulate(SimConfig(seed=seed, duration_s=dur, events=tuple(events), **kw))


class TestV1Determinism(unittest.TestCase):
    def test_same_seed_identical(self):
        ev = [sc.inlet_slug(600)]
        a, b = run(7, events=ev), run(7, events=ev)
        pd.testing.assert_frame_equal(a, b, check_exact=True)

    def test_different_seed_differs(self):
        a, b = run(1, dur=600), run(2, dur=600)
        self.assertGreater(np.abs(a["LT101"] - b["LT101"]).max(), 0.0)


class TestV2CommonRandomNumbers(unittest.TestCase):
    def test_identical_before_event_and_background_inflow_identical(self):
        t0 = 1200
        a = run(3, events=[])
        b = run(3, events=[sc.attack_level_spoof(t0)])
        pre = a["t"] < t0
        num = [c for c in a.columns if a[c].dtype != object]
        for c in num:
            np.testing.assert_array_equal(a.loc[pre, c].values, b.loc[pre, c].values, err_msg=c)
        np.testing.assert_array_equal(a["true_qin_base"].values, b["true_qin_base"].values)

    def test_sensor_noise_stream_independent_of_events(self):
        # PT101 is untouched by a level attack; its *noise* must be the same after the event,
        # so (PT101 - true pressure at read) can't be compared directly; check the noise stream
        # via a channel whose truth is unaffected: temperature sensor (T is process-driven only
        # when inlet is not tripped) -> compare using noise-only recomputation.
        a = run(4, dur=600, events=[])
        b = run(4, dur=600, events=[sc.sensor_fault_stuck(100, tag="FT102")])
        # LT101 truth+noise path unaffected by an FT102 fault -> must be identical
        np.testing.assert_array_equal(a["LT101"].values, b["LT101"].values)


class TestV3Equilibrium(unittest.TestCase):
    def test_equilibrium_holds_without_noise(self):
        df = run(0, dur=3600, sensor_noise=False, disturbances=False)
        self.assertLess(np.abs(df["true_level"] - 50.0).max(), 1e-6)
        self.assertLess(np.abs(df["true_pressure"] - 15.0).max(), 1e-6)


class TestV4Closure(unittest.TestCase):
    def _check(self, df, plant=PlantParams()):
        V0 = 0.5 * plant.v_total
        n0 = plant.pressure_sp * (plant.v_total - V0)
        dV = df["truth_V"].iloc[-1] - V0
        flow = (df["truth_vol_in"] - df["truth_vol_out"] - df["truth_vol_overflow"]).sum()
        self.assertLess(abs(dV - flow), 1e-6)
        dn = df["truth_n"].iloc[-1] - n0
        gflow = (df["truth_gas_in"] - df["truth_gas_out"] - df["truth_gas_relief"]).sum()
        self.assertLess(abs(dn - gflow), 1e-6)

    def test_closure_normal(self):
        self._check(run(5))

    def test_closure_under_attack_with_trip(self):
        df = run(6, dur=3600, events=[sc.attack_valve_force(300)])
        self.assertGreater(df["sis_tripped"].max(), 0.0, "expected SIS trip in this scenario")
        self._check(df)


class TestV4StressPaths(unittest.TestCase):
    """Exercise branches the SIS normally prevents, so closure is tested there too."""

    def test_overflow_path_closes_and_is_exercised(self):
        ev = [Event("S1", "actuator_force", "attack", 100, None, {"valve": "level", "value": 0.0})]
        df = run(8, dur=3600, events=ev, sis_enabled=False)
        self.assertGreater(df["truth_vol_overflow"].sum(), 0.0, "overflow path not exercised")
        TestV4Closure()._check(df)

    def test_relief_path_closes_and_is_exercised(self):
        ev = [Event("S2", "actuator_force", "attack", 100, None, {"valve": "pressure", "value": 0.0})]
        df = run(9, dur=3600, events=ev, sis_enabled=False)
        self.assertGreater(df["truth_gas_relief"].sum(), 0.0, "relief path not exercised")
        self.assertGreater(df["truth_psv_lift"].max(), 0.0)
        TestV4Closure()._check(df)


class TestAntiWindup(unittest.TestCase):
    def test_recovers_from_saturation_quickly(self):
        pi = PI(5.0, 900.0)
        for _ in range(2000):
            pi.step(60.0, 50.0, 1.0)        # e=+10 -> saturates at 100
        self.assertEqual(pi.step(60.0, 50.0, 1.0), 100.0)
        outs = [pi.step(49.0, 50.0, 1.0) for _ in range(5)]   # error reverses
        self.assertLess(outs[-1], 100.0, "integrator wound up: output still saturated")


class TestDistScale(unittest.TestCase):
    def test_default_unchanged_and_scale_monotone_and_crn(self):
        a, b = run(11, dur=1800), run(11, dur=1800, dist_scale=1.0)
        pd.testing.assert_frame_equal(a, b, check_exact=True)
        c = run(11, dur=1800, dist_scale=5.0)
        self.assertGreater(c["true_qin_base"].std(), 4.0 * a["true_qin_base"].std())
        # same underlying normals -> inflow deviations are exactly proportional
        np.testing.assert_allclose((c["true_qin_base"] - 100) / 5.0, a["true_qin_base"] - 100, atol=1e-9)


class TestLeakageGuard(unittest.TestCase):
    def test_observable_has_no_truth_columns(self):
        for c in OBSERVABLE:
            self.assertFalse(c.startswith(("true_", "truth_")))


if __name__ == "__main__":
    unittest.main()
