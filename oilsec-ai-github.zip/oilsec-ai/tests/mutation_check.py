"""Strict mutation check. Usage: python3 tests/mutation_check.py [sim|detect|triage|all]

For every mutant: copy the repo to a temp dir, apply ONE textual change, run the relevant unittest module.
Outcome KILLED = tests fail (good). SURVIVED = tests still pass (test gap). NOT_APPLIED = the pattern was not
found exactly once (the mutant is a no-op - this is an ERROR, never a pass). Exit code != 0 unless all KILLED.
"""
import os, shutil, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SIM = [
    ("S1 overflow unaccounted", "oilsec/sim/process.py", 'acc["vol_overflow"] += ovf', "pass"),
    ("S2 relief unaccounted", "oilsec/sim/process.py", 'acc["gas_relief"] += g_rel / 3600.0 * h * P0', "pass"),
    ("S3 gas_out mis-scaled", "oilsec/sim/process.py", 'acc["gas_out"] += g_out / 3600.0 * h * P0', 'acc["gas_out"] += g_out / 3600.0 * h'),
    ("S4 CRN broken", "oilsec/sim/runner.py", "eps_s = r_sens.standard_normal((n, len(TAGS)))",
     "eps_s = r_sens.standard_normal((n, len(TAGS))) * (1.0001 if cfg.events else 1.0)"),
    ("S5 equilibrium broken", "oilsec/sim/process.py", "kl: float = 200.0 / math.sqrt(0.5)", "kl: float = 200.1 / math.sqrt(0.5)"),
    ("S6 anti-windup removed", "oilsec/sim/process.py", "if not saturated_pushing:", "if True:"),
]
DETECT = [
    ("D1 level observer sign flipped", "oilsec/detect/twin.py", "lh += (F1[t] - F2[t])", "lh += (F2[t] - F1[t])"),
    ("D2 gas observer correction removed", "oilsec/detect/twin.py", "+ K * (PT[t] * vg - nh)", "+ 0.0"),
    ("D3 leakage guard removed", "oilsec/detect/base.py", "self._score(df[OBSERVABLE].copy())", "self._score(df.copy())"),
    ("D4 persistence ignored", "oilsec/detect/base.py", "rolling(persist, min_periods=persist)", "rolling(1, min_periods=1)"),
    ("D5 SP envelope level lower bound", "oilsec/detect/twin.py", "(o.sp_level.values < 35)", "(o.sp_level.values < 0)"),
    ("D6 valve lag frozen", "oilsec/detect/twin.py", "zl += (U1[t] - zl) * a", "zl += 0.0"),
    ("D7 rules HI limit loosened", "oilsec/detect/rules.py", "o.LT101 > 70", "o.LT101 > 95"),
    ("D8 warm-up not applied", "oilsec/detect/base.py", "        s[:WARMUP] = 0.0\n        return s\n\n    def fit", "        return s\n\n    def fit"),
    ("D9 gas outflow gain x2", "oilsec/detect/twin.py", "gout = self.kg * (Z2[t]", "gout = 2*self.kg * (Z2[t]"),
    ("D10 SP envelope pressure upper bound", "oilsec/detect/twin.py", "(o.sp_press.values > 18)", "(o.sp_press.values > 99)"),
    ("D11 SP envelope pressure lower bound", "oilsec/detect/twin.py", "(o.sp_press.values < 12)", "(o.sp_press.values < 0)"),
]
TRIAGE = [
    ("T1 causality leak", "oilsec/triage/evidence.py", "end = min(onset + W, n)", "end = min(onset + W + 50, n)"),
    ("T2 episode gap ignored", "oilsec/triage/evidence.py", "if i - p > gap:", "if i - p > 1:"),
    ("T3 context not coupled", "oilsec/triage/evidence.py",
     "np.random.default_rng(np.random.SeedSequence([int(seed), zlib.crc32(cname.encode()), 7]))", "np.random.default_rng()"),
    ("T4 IDS rates swapped", "oilsec/triage/evidence.py", '(cp.p_ids if cls == "attack" else cp.fp_ids)', '(cp.fp_ids if cls == "attack" else cp.p_ids)'),
    ("T5 numeric tolerance 500%", "oilsec/triage/report.py", "REL_TOL = 0.05", "REL_TOL = 5.0"),
    ("T6 confidence rank off-by-one", "oilsec/triage/report.py", '_RANK[c["confidence"]] > _RANK[conf_label(pmax)]', '_RANK[c["confidence"]] >= _RANK[conf_label(pmax)]'),
    ("T7 direction ignores sign", "oilsec/triage/report.py", 'true_dir = "increase" if ev["value"] > 0 else "decrease"', 'true_dir = "increase"'),
    ("T8 SP envelope level lower bound (channel flag)", "oilsec/detect/twin.py", "(o.sp_level.values < 35)", "(o.sp_level.values < 0)"),
    ("T9 verdict check disabled", "oilsec/triage/report.py", 'c["verdict"] != verdict', "False"),
    ("T10 valve_l channel dropped", "oilsec/detect/twin.py", "np.abs(r[i]) / self.scale[i] for i in range(4)",
     "np.abs(r[i]) / self.scale[i] if i != 2 else np.zeros(len(r[i])) for i in range(4)"),
]
SUITES = {"sim": (SIM, "tests.test_sim_core"), "detect": (DETECT, "tests.test_detectors"), "triage": (TRIAGE, "tests.test_triage")}


def run_mutant(name, rel, old, new, module):
    tmp = tempfile.mkdtemp()
    try:
        dst = os.path.join(tmp, "w")
        shutil.copytree(ROOT, dst, ignore=shutil.ignore_patterns("__pycache__", "results", "*.zip", ".git"))
        p = os.path.join(dst, rel)
        src = open(p).read()
        if src.count(old) != 1:
            return "NOT_APPLIED", f"pattern occurs {src.count(old)} times in {rel}"
        open(p, "w").write(src.replace(old, new, 1))
        r = subprocess.run([sys.executable, "-m", "unittest", module], cwd=dst, capture_output=True, text=True)
        return ("SURVIVED" if r.returncode == 0 else "KILLED"), ""
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main(which):
    names = list(SUITES) if which == "all" else [which]
    bad = 0
    for s in names:
        muts, module = SUITES[s]
        for name, rel, old, new in muts:
            status, why = run_mutant(name, rel, old, new, module)
            print(f"[{s}] {name:50s} {status} {why}", flush=True)
            bad += status != "KILLED"
    print("ALL KILLED" if bad == 0 else f"{bad} mutant(s) not killed")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "all"))
