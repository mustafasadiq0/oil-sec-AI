import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from .evidence import SIGNAL_COLS, CTX_COLS

CLASSES = ["attack", "benign", "fault"]


def fit_predict_proba(train, test, use_ctx):
    cols = SIGNAL_COLS + (CTX_COLS if use_ctx else [])
    m = RandomForestClassifier(n_estimators=300, random_state=0, class_weight="balanced", n_jobs=1)
    m.fit(train[cols].values, train["cls"].values)
    P = np.zeros((len(test), len(CLASSES)))
    for j, c in enumerate(m.classes_):
        P[:, CLASSES.index(c)] = m.predict_proba(test[cols].values)[:, j]
    return P


def macro_f1(y, pred):
    return float(f1_score(y, pred, labels=CLASSES, average="macro", zero_division=0))


def predict_labels(P):
    return np.array(CLASSES)[P.argmax(axis=1)]


def cluster_bootstrap_delta(test, pred_a, pred_b, n_boot=2000, seed=0):
    """CI for macro-F1(a) - macro-F1(b), resampling SEEDS (clusters) with replacement."""
    rng = np.random.default_rng(seed)
    seeds = np.unique(test["seed"].values)
    idx_by = {s: np.where(test["seed"].values == s)[0] for s in seeds}
    y = test["cls"].values
    d = []
    for _ in range(n_boot):
        pick = rng.choice(seeds, size=len(seeds), replace=True)
        ix = np.concatenate([idx_by[s] for s in pick])
        d.append(macro_f1(y[ix], pred_a[ix]) - macro_f1(y[ix], pred_b[ix]))
    return float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5)), float(np.mean(d))
