"""Deterministic investigator STAND-IN + mechanical claim verifier.

This is NOT an LLM. It emits structured claims that cite evidence IDs. The verifier checks each claim against the
evidence package and classifier output. Free-text claim extraction (the hard part for a real LLM) is out of scope.

Each check is the sole owner of its failure type, so ablating a check must reduce recall for that type.
"""
import copy
import numpy as np
from .classify import CLASSES

ALL_CHECKS = ("id_exists", "value_match", "direction", "verdict_consistency", "confidence_calibration")
REL_TOL = 0.05
ABS_TOL = 1e-3
STAT_KEYS = ["res_level", "res_gas", "res_valve_l", "res_valve_p"]
CTX_KEYS = ["change_ticket", "maint_ticket", "ids_alert"]
FIRED = ["fired_D1", "fired_D2", "fired_D3", "fired_D4"]


def conf_label(p):
    return "high" if p >= 0.9 else ("moderate" if p >= 0.6 else "low")


_RANK = {"low": 0, "moderate": 1, "high": 2}


def generate_report(items, probs):
    by_key = {it["key"]: it for it in items}
    verdict = CLASSES[int(np.argmax(probs))]
    p = float(np.max(probs))
    claims = []
    top = sorted((k for k in STAT_KEYS if k in by_key), key=lambda k: -by_key[k]["value"])[:2]
    for k in top:
        claims.append(dict(type="numeric", cite=by_key[k]["id"], metric=k, value=round(by_key[k]["value"], 3)))
    for k in FIRED:
        if k in by_key:
            claims.append(dict(type="numeric", cite=by_key[k]["id"], metric=k, value=by_key[k]["value"]))
    for k in ("d_sp_level", "d_lt", "d_pt"):
        if k in by_key and abs(by_key[k]["value"]) > 1.0:
            claims.append(dict(type="direction", cite=by_key[k]["id"], metric=k,
                               direction="increase" if by_key[k]["value"] > 0 else "decrease"))
    flat = [k for k in ("std_LT101", "std_PT101", "std_FT101", "std_FT102") if k in by_key and by_key[k]["value"] < 1e-9]
    for k in flat:
        claims.append(dict(type="numeric", cite=by_key[k]["id"], metric=k, value=0.0))
    for k in CTX_KEYS:
        if k in by_key:
            claims.append(dict(type="numeric", cite=by_key[k]["id"], metric=k, value=by_key[k]["value"]))
    claims.append(dict(type="verdict", verdict=verdict, confidence=conf_label(p), p=round(p, 3)))
    return dict(claims=claims)


def verify(report, items, probs, checks=ALL_CHECKS):
    by_id = {it["id"]: it for it in items}
    verdict = CLASSES[int(np.argmax(probs))]
    pmax = float(np.max(probs))
    viol = []
    for i, c in enumerate(report["claims"]):
        if c["type"] == "verdict":
            if "verdict_consistency" in checks and c["verdict"] != verdict:
                viol.append((i, "verdict_consistency"))
            if "confidence_calibration" in checks and _RANK[c["confidence"]] > _RANK[conf_label(pmax)]:
                viol.append((i, "confidence_calibration"))
            continue
        ev = by_id.get(c["cite"])
        if ev is None:
            if "id_exists" in checks:
                viol.append((i, "id_exists"))
            continue                                   # nothing else can be checked without evidence
        if c["type"] == "numeric" and "value_match" in checks:
            if ev["key"] != c["metric"] or abs(ev["value"] - c["value"]) > max(ABS_TOL, REL_TOL * abs(ev["value"])):
                viol.append((i, "value_match"))
        if c["type"] == "direction" and "direction" in checks:
            true_dir = "increase" if ev["value"] > 0 else "decrease"
            if ev["key"] != c["metric"] or c["direction"] != true_dir:
                viol.append((i, "direction"))
    return viol


# ---------------- corruption injectors (for verifier red-teaming) ----------------
def corrupt(report, kind, rng, probs):
    r = copy.deepcopy(report)
    cl = r["claims"]
    if kind == "numeric_alteration":
        cand = [c for c in cl if c["type"] == "numeric"]
        if not cand:
            return None
        c = cand[rng.integers(len(cand))]
        c["value"] = (1.0 - c["value"]) if c["value"] in (0.0, 1.0) else c["value"] * float(rng.choice([1.5, 0.5]))
    elif kind == "nonexistent_evidence":
        cand = [c for c in cl if c["type"] != "verdict"]
        if not cand:
            return None
        cand[rng.integers(len(cand))]["cite"] = "E999"
    elif kind == "direction_flip":
        cand = [c for c in cl if c["type"] == "direction"]
        if not cand:
            return None
        c = cand[rng.integers(len(cand))]
        c["direction"] = "decrease" if c["direction"] == "increase" else "increase"
    elif kind == "verdict_flip":
        v = [c for c in cl if c["type"] == "verdict"][0]
        v["verdict"] = [x for x in CLASSES if x != v["verdict"]][int(rng.integers(2))]
    elif kind == "overconfidence":
        if float(np.max(probs)) >= 0.9:
            return None
        [c for c in cl if c["type"] == "verdict"][0]["confidence"] = "high"
    else:
        raise ValueError(kind)
    return r


CORRUPTIONS = ["numeric_alteration", "nonexistent_evidence", "direction_flip", "verdict_flip", "overconfidence"]
OWNER = {"numeric_alteration": "value_match", "nonexistent_evidence": "id_exists", "direction_flip": "direction",
         "verdict_flip": "verdict_consistency", "overconfidence": "confidence_calibration"}
