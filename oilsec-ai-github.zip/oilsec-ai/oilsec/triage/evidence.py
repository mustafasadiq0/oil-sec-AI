"""Episode extraction, causal evidence features, and the SYNTHETIC provenance context model.

Causality: features use only samples with index < onset + W (triage happens W seconds after onset).
Everything signal-based comes from OBSERVABLE columns. Context is synthetic and generated from labels
with ASSUMED reliabilities (see Notebook 05) - results must be read as curves vs those assumptions.
"""
import zlib
from dataclasses import dataclass
import numpy as np
import pandas as pd
from ..sim.runner import OBSERVABLE

GAP = 60
W = 120
DETS = ["D1", "D2", "D3", "D4"]
RES_NAMES = ["level", "gas", "valve_l", "valve_p"]


def find_episodes(alert, gap=GAP):
    idx = np.where(np.asarray(alert, bool))[0]
    if len(idx) == 0:
        return []
    eps, s, p = [], idx[0], idx[0]
    for i in idx[1:]:
        if i - p > gap:
            eps.append((int(s), int(p))); s = i
        p = i
    eps.append((int(s), int(p)))
    return eps


def first_episode(eps, lo, hi):
    for s, e in eps:
        if lo <= s < hi:
            return (s, e)
    return None


def signal_features(df, onset, alerts, ch):
    """alerts: dict D1..D4 -> bool array; ch: (n,5) twin channel scores. Uses samples < onset+W only."""
    o = df[OBSERVABLE]
    n = len(o)
    end = min(onset + W, n)
    lo = max(onset - 60, 0)
    f = {}
    for name in DETS:
        seg = np.asarray(alerts[name])[onset:end]
        f[f"fired_{name}"] = float(seg.any())
        f[f"lag_{name}"] = float(np.argmax(seg)) if seg.any() else float(W)
    pk = ch[max(onset - 5, 0):end].max(axis=0)
    for i, nm in enumerate(RES_NAMES):
        f[f"res_{nm}"] = float(np.log1p(min(pk[i], 1e4)))
    f["res_sp"] = float(pk[4])
    f["d_sp_level"] = float(o.sp_level.values[end - 1] - o.sp_level.values[lo])
    f["d_sp_press"] = float(o.sp_press.values[end - 1] - o.sp_press.values[lo])
    f["d_lt"] = float(o.LT101.values[end - 1] - o.LT101.values[lo])
    f["d_pt"] = float(o.PT101.values[end - 1] - o.PT101.values[lo])
    for t in ("LT101", "PT101", "FT101", "FT102"):
        f[f"std_{t}"] = float(o[t].values[onset:end].std())
    f["gap_zl"] = float((o.ZT101.values[onset:end] - o.u_level_calc.values[onset:end]).mean())
    f["gap_zp"] = float((o.ZT102.values[onset:end] - o.u_press_calc.values[onset:end]).mean())
    f["sis"] = float(o.sis_tripped.values[onset:end].max())
    return f


SIGNAL_COLS = ([f"{p}_{d}" for d in DETS for p in ("fired", "lag")] + [f"res_{n}" for n in RES_NAMES] + ["res_sp"]
               + ["d_sp_level", "d_sp_press", "d_lt", "d_pt", "std_LT101", "std_PT101", "std_FT101", "std_FT102",
                  "gap_zl", "gap_zp", "sis"])
CTX_COLS = ["change_ticket", "maint_ticket", "ids_alert"]


@dataclass(frozen=True)
class ContextParams:
    p_ids: float = 0.5
    q_forge: float = 0.1
    p_ticket_B3: float = 0.9
    p_ticket_B2: float = 0.5
    p_ticket_B1: float = 0.0
    p_maint: float = 0.3
    fp_ids: float = 0.05


def make_context(cname, cls, seed, cp=ContextParams()):
    """Fixed uniforms per (seed, condition) -> outcomes are monotone in the parameters (coupled sweeps)."""
    u = np.random.default_rng(np.random.SeedSequence([int(seed), zlib.crc32(cname.encode()), 7])).random(3)
    ticket, maint = 0.0, 0.0
    if cls == "benign":
        p = {"B3": cp.p_ticket_B3, "B2": cp.p_ticket_B2, "B1": cp.p_ticket_B1}.get(cname, 0.0)
        ticket = float(u[0] < p)
    elif cls == "attack" and cname.startswith("A3"):
        ticket = float(u[0] < cp.q_forge)
    if cls == "fault":
        maint = float(u[2] < cp.p_maint)
    ids = float(u[1] < (cp.p_ids if cls == "attack" else cp.fp_ids))
    return dict(change_ticket=ticket, maint_ticket=maint, ids_alert=ids)


def evidence_items(feat):
    """Ordered, ID-stamped evidence list from a feature dict (signal + ctx keys)."""
    keys = [k for k in SIGNAL_COLS + CTX_COLS if k in feat]
    return [dict(id=f"E{i + 1}", key=k, value=float(feat[k])) for i, k in enumerate(keys)]
