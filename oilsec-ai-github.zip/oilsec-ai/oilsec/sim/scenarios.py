"""Scenario events with ground-truth labels.

Labels (priority order when events overlap): attack > fault > benign_disturbance > normal.

Honest caveat: `sensor_stuck` is the same physical mechanism whether caused by an attacker
(label='attack') or a hardware failure (label='fault'). Any detector working only on
PLC-visible data cannot separate them by signature; separation needs provenance/context.
"""
from dataclasses import dataclass, field
from typing import Optional

LABEL_PRIORITY = {"normal": 0, "benign_disturbance": 1, "fault": 2, "attack": 3}
VALID_KINDS = {
    "inlet_slug", "well_switch", "setpoint_change",
    "sensor_stuck", "sensor_bias", "sensor_ramp", "actuator_force",
}


@dataclass(frozen=True)
class Event:
    event_id: str
    kind: str
    label: str
    t_start: float
    duration: Optional[float] = None  # None = until end of run
    params: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.kind not in VALID_KINDS:
            raise ValueError(f"unknown event kind {self.kind!r}")
        if self.label not in LABEL_PRIORITY or self.label == "normal":
            raise ValueError(f"invalid event label {self.label!r}")

    def active(self, t: float) -> bool:
        return t >= self.t_start and (self.duration is None or t < self.t_start + self.duration)

    @property
    def t_end(self) -> Optional[float]:
        return None if self.duration is None else self.t_start + self.duration


# ---- benign disturbances ---------------------------------------------------
def inlet_slug(t0, mag=0.40, duration=120.0, eid="B1_slug"):
    return Event(eid, "inlet_slug", "benign_disturbance", t0, duration, {"mag": mag})


def well_switch(t0, mag=0.20, eid="B2_well_switch"):
    return Event(eid, "well_switch", "benign_disturbance", t0, None, {"mag": mag})


def operator_setpoint(t0, loop="level", value=55.0, eid="B3_operator_sp"):
    return Event(eid, "setpoint_change", "benign_disturbance", t0, None,
                 {"loop": loop, "value": value, "authorised": True})


# ---- faults ----------------------------------------------------------------
def sensor_fault_stuck(t0, tag="FT102", duration=1800.0, eid="F1_ft102_stuck"):
    return Event(eid, "sensor_stuck", "fault", t0, duration, {"tag": tag})


def sensor_fault_stuck_level(t0, duration=1800.0, eid="F2_lt101_stuck"):
    return Event(eid, "sensor_stuck", "fault", t0, duration, {"tag": "LT101"})


# ---- attacks (all act at the PLC I/O boundary) ------------------------------
def attack_level_spoof(t0, offset=-35.0, duration=1500.0, eid="A1_level_spoof"):
    return Event(eid, "sensor_bias", "attack", t0, duration, {"tag": "LT101", "offset": offset})


def attack_level_freeze(t0, duration=1800.0, eid="A2_level_freeze"):
    return Event(eid, "sensor_stuck", "attack", t0, duration, {"tag": "LT101"})


def attack_setpoint_tamper(t0, value=80.0, duration=1500.0, eid="A3_sp_tamper"):
    return Event(eid, "setpoint_change", "attack", t0, duration,
                 {"loop": "level", "value": value, "authorised": False})


def attack_valve_force(t0, value=5.0, duration=1500.0, eid="A4_valve_force"):
    return Event(eid, "actuator_force", "attack", t0, duration, {"valve": "level", "value": value})


def attack_pressure_ramp(t0, rate=-0.01, duration=600.0, eid="A5_pressure_ramp"):
    return Event(eid, "sensor_ramp", "attack", t0, duration, {"tag": "PT101", "rate": rate})


ATTACK_FACTORIES = {
    "A1_level_spoof": attack_level_spoof,
    "A2_level_freeze": attack_level_freeze,
    "A3_sp_tamper": attack_setpoint_tamper,
    "A4_valve_force": attack_valve_force,
    "A5_pressure_ramp": attack_pressure_ramp,
}
BENIGN_FACTORIES = {
    "B1_slug": inlet_slug,
    "B2_well_switch": well_switch,
    "B3_operator_sp": operator_setpoint,
}
FAULT_FACTORIES = {
    "F1_ft102_stuck": sensor_fault_stuck,
    "F2_lt101_stuck": sensor_fault_stuck_level,
}
