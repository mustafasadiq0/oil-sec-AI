"""Stylised two-phase separator.  NOT calibrated against any real facility.

States
  V  liquid volume [m3]            level% = 100 V / v_total
  n  gas inventory [bar*m3]        P = n / (v_total - V)   (isothermal ideal gas, T ignored in P)
  T  temperature [degC]            first-order lag to feed temperature
  z_l, z_p  valve positions [%]    first-order actuator lag

Flows
  liquid out  = kl * z_l/100 * sqrt(level_frac)         [m3/h]
  gas out     = kg * z_p/100 * sqrt(max(P - p_down,0))  [Nm3/h]
  PSV relief  = k_relief * max(P - p_relief, 0)         [Nm3/h]
  liquid overflow above v_max_frac is diverted and *accounted* (so mass balance closes).
Units: 1 Nm3 is treated as P0 = 1.01325 bar*m3 of gas inventory.
"""
import math
from dataclasses import dataclass

P0 = 1.01325


@dataclass(frozen=True)
class PlantParams:
    v_total: float = 80.0
    v_max_frac: float = 0.98
    kl: float = 200.0 / math.sqrt(0.5)      # gives 100 m3/h at 50% valve, 50% level
    kg: float = 2000.0 / math.sqrt(10.0)    # gives 1000 Nm3/h at 50% valve, 15 bar
    p_down: float = 5.0
    p_relief: float = 22.0
    k_relief: float = 2000.0
    gor: float = 10.0                       # Nm3 gas per m3 liquid
    tau_valve: float = 5.0
    tau_temp: float = 600.0
    q_in_nom: float = 100.0
    level_sp: float = 50.0
    pressure_sp: float = 15.0
    temp_feed_mean: float = 60.0
    temp_ambient: float = 35.0


@dataclass(frozen=True)
class ControlParams:
    kp_level: float = 5.0
    ti_level: float = 900.0
    kp_press: float = 40.0
    ti_press: float = 300.0


class Plant:
    def __init__(self, p: PlantParams):
        self.p = p
        self.V = 0.5 * p.v_total
        self.n = p.pressure_sp * (p.v_total - self.V)
        self.T = p.temp_feed_mean
        self.z_l = 50.0
        self.z_p = 50.0

    @property
    def level_pct(self):
        return 100.0 * self.V / self.p.v_total

    @property
    def pressure(self):
        return self.n / (self.p.v_total - self.V)

    def advance(self, dt, substeps, q_in, g_in, u_l, u_p, t_feed):
        """Zero-order-hold inputs over dt. Returns integrals (for exact bookkeeping)."""
        p = self.p
        h = dt / substeps
        a_v = 1.0 - math.exp(-h / p.tau_valve)
        a_t = 1.0 - math.exp(-h / p.tau_temp)
        acc = dict(vol_in=0.0, vol_out=0.0, vol_overflow=0.0,
                   gas_in=0.0, gas_out=0.0, gas_relief=0.0, psv_lift=0.0)
        for _ in range(substeps):
            self.z_l += (u_l - self.z_l) * a_v
            self.z_p += (u_p - self.z_p) * a_v
            lf = max(self.V / p.v_total, 0.01)
            P = self.n / (p.v_total - self.V)
            q_out = p.kl * (self.z_l / 100.0) * math.sqrt(lf)                  # m3/h
            g_out = p.kg * (self.z_p / 100.0) * math.sqrt(max(P - p.p_down, 0.0))
            g_rel = p.k_relief * max(P - p.p_relief, 0.0)
            # liquid cannot go below zero
            q_out = min(q_out, (self.V / h + q_in / 3600.0 * 1.0) * 3600.0) if h > 0 else q_out
            V_new = self.V + (q_in - q_out) / 3600.0 * h
            ovf = 0.0
            v_cap = p.v_max_frac * p.v_total
            if V_new > v_cap:
                ovf = V_new - v_cap
                V_new = v_cap
            # gas cannot go below zero inventory
            dn = (g_in - g_out - g_rel) * P0 / 3600.0 * h
            if self.n + dn < 1e-6:
                dn = 1e-6 - self.n
            self.V, self.n = V_new, self.n + dn
            self.T += (t_feed - self.T) * a_t
            acc["vol_in"] += q_in / 3600.0 * h
            acc["vol_out"] += q_out / 3600.0 * h
            acc["vol_overflow"] += ovf
            acc["gas_in"] += g_in / 3600.0 * h * P0
            acc["gas_out"] += g_out / 3600.0 * h * P0
            acc["gas_relief"] += g_rel / 3600.0 * h * P0
            if g_rel > 0.0:
                acc["psv_lift"] = 1.0
        acc["q_out_end"] = q_out
        return acc


class PI:
    """Positional PI with conditional-integration anti-windup. direct=True: u rises with pv."""

    def __init__(self, kp, ti, u0=50.0, lo=0.0, hi=100.0):
        self.kp, self.ti, self.i, self.lo, self.hi = kp, ti, u0, lo, hi

    def step(self, pv, sp, dt):
        e = pv - sp
        i_new = self.i + self.kp / self.ti * e * dt
        u_raw = self.kp * e + i_new
        u = min(max(u_raw, self.lo), self.hi)
        saturated_pushing = (u_raw > self.hi and e > 0) or (u_raw < self.lo and e < 0)
        if not saturated_pushing:
            self.i = i_new
        return u


class SIS:
    """Independent safety trip: closes inlet. Latched; auto-reset after conditions stay clear."""

    def __init__(self, l_hh=85.0, l_ll=10.0, p_hh=19.0, l_clear_hi=75.0, l_clear_lo=20.0,
                 p_clear=17.0, reset_delay=300.0, ramp=60.0):
        self.l_hh, self.l_ll, self.p_hh = l_hh, l_ll, p_hh
        self.l_clear_hi, self.l_clear_lo, self.p_clear = l_clear_hi, l_clear_lo, p_clear
        self.reset_delay, self.ramp = reset_delay, ramp
        self.tripped = False
        self.clear_time = 0.0
        self.ramp_t = ramp
        self.trip_count = 0

    def update(self, level, pressure, dt):
        trip_cond = level > self.l_hh or level < self.l_ll or pressure > self.p_hh
        if not self.tripped and trip_cond:
            self.tripped, self.clear_time, self.ramp_t = True, 0.0, 0.0
            self.trip_count += 1
        elif self.tripped:
            clear = (self.l_clear_lo < level < self.l_clear_hi) and pressure < self.p_clear
            self.clear_time = self.clear_time + dt if clear else 0.0
            if self.clear_time >= self.reset_delay:
                self.tripped = False
        if not self.tripped:
            self.ramp_t = min(self.ramp_t + dt, self.ramp)
        return 0.0 if self.tripped else self.ramp_t / self.ramp
