"""Simulation runner.

Scan order (1 s):  disturbances -> SIS -> sensors -> sensor attacks/faults -> PLC -> actuator
forcing -> plant integration -> logging.

RNG design: three independent streams (process, sensor, sis). Each draws a FIXED number of
variates per step regardless of scenario, so two runs with the same seed but different
event lists share identical background noise (common random numbers).

Data-leakage guard: columns in OBSERVABLE are what a SCADA/historian could see. Anything
prefixed `true_` or `truth_` is simulator ground truth and must never feed a detector.
"""
import math
from dataclasses import dataclass, field
import numpy as np
import pandas as pd

from .process import Plant, PlantParams, ControlParams, PI, SIS
from .scenarios import LABEL_PRIORITY

TAGS = ["LT101", "PT101", "TT101", "FT101", "FT102", "ZT101", "ZT102"]
SENSOR_SIGMA = {"LT101": 0.15, "PT101": 0.03, "TT101": 0.10, "FT101": 0.8,
                "FT102": 0.8, "ZT101": 0.2, "ZT102": 0.2}
SIS_SIGMA = (0.2, 0.05)
OU_Q = (0.03, 300.0)      # sigma (relative), tau [s]  inlet liquid
OU_G = (0.03, 200.0)      # gas-oil-ratio fluctuation
OU_T = (0.5, 1800.0)      # feed temperature [degC]

OBSERVABLE = TAGS + ["u_level_calc", "u_press_calc", "sp_level", "sp_press", "sis_tripped"]


@dataclass
class SimConfig:
    seed: int = 0
    duration_s: int = 3600
    substeps: int = 5
    sensor_noise: bool = True
    disturbances: bool = True
    dist_scale: float = 1.0    # multiplies OU disturbance sigmas (robustness axis)
    sis_enabled: bool = True   # False ONLY for physics stress tests (exercise overflow/relief paths)
    events: tuple = ()
    plant: PlantParams = field(default_factory=PlantParams)
    control: ControlParams = field(default_factory=ControlParams)


def _ou(eps, sigma, tau, dt=1.0):
    phi = math.exp(-dt / tau)
    out = np.empty_like(eps)
    x = sigma * eps[0]
    out[0] = x
    s = sigma * math.sqrt(1.0 - phi * phi)
    for k in range(1, len(eps)):
        x = phi * x + s * eps[k]
        out[k] = x
    return out


def _sensor_effect(tag, val, t, active, frozen):
    for e in active:
        if e.params.get("tag") != tag:
            continue
        if e.kind == "sensor_stuck":
            frozen.setdefault(e.event_id, val)
            val = frozen[e.event_id]
        elif e.kind == "sensor_bias":
            val += e.params["offset"]
        elif e.kind == "sensor_ramp":
            val += e.params["rate"] * (t - e.t_start)
    return val


def simulate(cfg: SimConfig) -> pd.DataFrame:
    p, c = cfg.plant, cfg.control
    n = int(cfg.duration_s)
    ss = np.random.SeedSequence(cfg.seed)
    r_proc, r_sens, r_sis = (np.random.default_rng(s) for s in ss.spawn(3))
    eps_p = r_proc.standard_normal((n, 3))
    eps_s = r_sens.standard_normal((n, len(TAGS)))
    eps_i = r_sis.standard_normal((n, 2))

    if cfg.disturbances:
        ds = cfg.dist_scale
        ou_q = _ou(eps_p[:, 0], OU_Q[0] * ds, OU_Q[1])
        ou_g = _ou(eps_p[:, 1], OU_G[0] * ds, OU_G[1])
        ou_t = _ou(eps_p[:, 2], OU_T[0] * ds, OU_T[1])
    else:
        ou_q = ou_g = ou_t = np.zeros(n)
    sig = np.array([SENSOR_SIGMA[t] for t in TAGS]) * (1.0 if cfg.sensor_noise else 0.0)

    plant = Plant(p)
    pi_l = PI(c.kp_level, c.ti_level)
    pi_p = PI(c.kp_press, c.ti_press)
    sis = SIS()
    frozen = {}
    q_out_prev = p.q_in_nom
    events = list(cfg.events)

    cols = {k: np.empty(n) for k in (
        ["t"] + TAGS + ["u_level_calc", "u_press_calc", "sp_level", "sp_press", "sis_tripped",
                        "u_level_applied", "u_press_applied",
                        "true_level", "true_pressure", "true_temp", "true_q_in", "true_q_out",
                        "true_qin_base", "true_inlet_factor", "true_zl", "true_zp",
                        "truth_vol_in", "truth_vol_out", "truth_vol_overflow",
                        "truth_gas_in", "truth_gas_out", "truth_gas_relief", "truth_psv_lift",
                        "truth_V", "truth_n"])}
    labels, sids = [], []

    for k in range(n):
        t = float(k)
        active = [e for e in events if e.active(t)]

        # 1 disturbances
        q_base = p.q_in_nom * (1.0 + ou_q[k])
        scale = 1.0
        for e in active:
            if e.kind in ("inlet_slug", "well_switch"):
                scale *= 1.0 + e.params["mag"]
        t_feed = p.temp_feed_mean + 3.0 * math.sin(2 * math.pi * t / 86400.0) + ou_t[k]

        # 2 SIS (independent hardwired sensors, own noise)
        sis_l = plant.level_pct + SIS_SIGMA[0] * eps_i[k, 0]
        sis_p = plant.pressure + SIS_SIGMA[1] * eps_i[k, 1]
        factor = sis.update(sis_l, sis_p, 1.0) if cfg.sis_enabled else 1.0
        q_in = q_base * scale * factor
        g_in = p.gor * q_in * (1.0 + ou_g[k])
        if factor == 0.0:
            t_feed = p.temp_ambient

        # 3 sensors (true -> noisy)
        true_vals = [plant.level_pct, plant.pressure, plant.T, q_in, q_out_prev, plant.z_l, plant.z_p]
        meas = {tag: true_vals[i] + sig[i] * eps_s[k, i] for i, tag in enumerate(TAGS)}
        # 4 sensor attacks / faults at PLC input boundary
        for tag in TAGS:
            meas[tag] = _sensor_effect(tag, meas[tag], t, active, frozen)

        # 5 setpoints (latest-started active change wins)
        sp_l, sp_p = p.level_sp, p.pressure_sp
        for e in sorted((e for e in active if e.kind == "setpoint_change"), key=lambda e: e.t_start):
            if e.params["loop"] == "level":
                sp_l = e.params["value"]
            else:
                sp_p = e.params["value"]

        # 6 PLC
        u_l = pi_l.step(meas["LT101"], sp_l, 1.0)
        u_p = pi_p.step(meas["PT101"], sp_p, 1.0)
        # 7 actuator forcing at output stage (PLC still *reports* its own calc)
        a_l, a_p = u_l, u_p
        for e in active:
            if e.kind == "actuator_force":
                if e.params["valve"] == "level":
                    a_l = e.params["value"]
                else:
                    a_p = e.params["value"]

        # 8 plant
        acc = plant.advance(1.0, cfg.substeps, q_in, g_in, a_l, a_p, t_feed)
        q_out_prev = acc["q_out_end"]

        # 9 log
        cols["t"][k] = t
        for tag in TAGS:
            cols[tag][k] = meas[tag]
        cols["u_level_calc"][k], cols["u_press_calc"][k] = u_l, u_p
        cols["sp_level"][k], cols["sp_press"][k] = sp_l, sp_p
        cols["sis_tripped"][k] = 1.0 if sis.tripped else 0.0
        cols["u_level_applied"][k], cols["u_press_applied"][k] = a_l, a_p
        cols["true_level"][k], cols["true_pressure"][k] = plant.level_pct, plant.pressure
        cols["true_temp"][k] = plant.T
        cols["true_q_in"][k], cols["true_q_out"][k] = q_in, acc["q_out_end"]
        cols["true_qin_base"][k], cols["true_inlet_factor"][k] = q_base, factor
        cols["true_zl"][k], cols["true_zp"][k] = plant.z_l, plant.z_p
        for key in ("vol_in", "vol_out", "vol_overflow", "gas_in", "gas_out", "gas_relief", "psv_lift"):
            cols["truth_" + key][k] = acc[key]
        cols["truth_V"][k], cols["truth_n"][k] = plant.V, plant.n

        if active:
            top = max(active, key=lambda e: (LABEL_PRIORITY[e.label], e.t_start))
            labels.append(top.label)
            sids.append(top.event_id)
        else:
            labels.append("normal")
            sids.append("")

    df = pd.DataFrame(cols)
    df["label"], df["scenario_id"] = labels, sids
    df.attrs["events"] = events
    df.attrs["seed"] = cfg.seed
    df.attrs["sis_trip_count"] = sis.trip_count
    return df
