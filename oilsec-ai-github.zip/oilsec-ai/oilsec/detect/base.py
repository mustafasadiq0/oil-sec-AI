"""Detector base class. Structural leakage guard: subclasses only ever receive df[OBSERVABLE]."""
import numpy as np
import pandas as pd
from ..sim.runner import OBSERVABLE

WARMUP = 120
PERSIST = 5


def sustained(score: np.ndarray, persist: int = PERSIST) -> np.ndarray:
    """rolling minimum over `persist` samples: high only if score stayed high that long."""
    return pd.Series(score).rolling(persist, min_periods=persist).min().fillna(0.0).values


class Detector:
    name = "base"
    fixed_threshold = None   # rule-based detectors set this

    def __init__(self):
        self.thr = self.fixed_threshold

    # ---- subclass API (receives OBSERVABLE columns only) ----
    def _fit(self, runs): pass
    def _score(self, obs: pd.DataFrame) -> np.ndarray: raise NotImplementedError

    # ---- public API ----
    def score(self, df: pd.DataFrame) -> np.ndarray:
        s = np.array(self._score(df[OBSERVABLE].copy()), dtype=float)
        s[:WARMUP] = 0.0
        return s

    def fit(self, dfs):
        runs = [d[OBSERVABLE].copy() for d in dfs]
        self._fit(runs)
        if self.fixed_threshold is None:
            self.thr = max(float(sustained(self.score_obs(r)).max()) for r in runs)
        return self

    def score_obs(self, obs):
        s = np.array(self._score(obs), dtype=float); s[:WARMUP] = 0.0; return s

    def alerts(self, df: pd.DataFrame, thr=None) -> np.ndarray:
        t = self.thr if thr is None else thr
        return sustained(self.score(df)) > t
