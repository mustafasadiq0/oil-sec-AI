import numpy as np
from .base import Detector


class AlarmRules(Detector):
    """D1: conventional HI/LO alarm limits on PLC-visible level and pressure."""
    name = "D1_rules"
    fixed_threshold = 0.5

    def _score(self, o):
        return ((o.LT101 > 70) | (o.LT101 < 30) | (o.PT101 > 18) | (o.PT101 < 12)).astype(float).values
