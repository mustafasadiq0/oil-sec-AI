import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from .base import Detector

CH = ["LT101", "PT101", "TT101", "FT101", "FT102", "ZT101", "ZT102", "u_level_calc", "u_press_calc"]
STEP = 5


def features(o, win=60):
    f = {}
    for c in CH:
        r = o[c].rolling(win, min_periods=win)
        f[c + "_m"] = r.mean(); f[c + "_s"] = r.std(); f[c + "_d"] = o[c] - o[c].shift(win - 1)
    f["sp_level"] = o["sp_level"]; f["sp_press"] = o["sp_press"]
    return pd.DataFrame(f)


class IForest(Detector):
    """D3: unsupervised multivariate anomaly detector on windowed features, scored every 5 s."""
    name = "D3_iforest"

    def _fit(self, runs):
        X = pd.concat([features(r).iloc[120::STEP] for r in runs]).dropna()
        self.m = IsolationForest(n_estimators=100, random_state=0).fit(X.values)

    def _score(self, o):
        F = features(o); n = len(F)
        idx = np.arange(120, n, STEP)
        s = np.zeros(n)
        vals = -self.m.score_samples(F.iloc[idx].fillna(0.0).values)
        for j, i in enumerate(idx):
            s[i:i + STEP] = vals[j]
        return s
