"""D4: physics-consistency detector (digital-twin residuals) using ONLY PLC-visible signals.

INVERSE-CRIME WARNING: the observers below reuse the simulator's own equations (same sqrt valve laws,
same first-order valve lag). Performance is an UPPER BOUND for twin-based detection. D4m perturbs
parameters and valve tau to probe sensitivity, but not model structure.
"""
import math
import numpy as np
from .base import Detector
from ..sim.process import PlantParams, P0

BIG = 1e6
WARMUP_ = 120
K_OBS = 0.005


class Twin(Detector):
    name = "D4_twin"

    def __init__(self, kg_scale=1.0, gor_scale=1.0, vt_scale=1.0, tau_valve=5.0, name=None, k_obs=K_OBS,
                 use=("level", "gas", "valve_l", "valve_p", "sp")):
        super().__init__()
        p = PlantParams()
        self.kg, self.gor, self.vt = p.kg * kg_scale, p.gor * gor_scale, p.v_total * vt_scale
        self.p_down, self.tau, self.k, self.use = p.p_down, tau_valve, k_obs, set(use)
        if name:
            self.name = name

    @staticmethod
    def _sp_bad(o):
        """Engineering envelope for setpoint registers (single source of truth)."""
        return (o.sp_level.values < 35) | (o.sp_level.values > 65) | (o.sp_press.values < 12) | (o.sp_press.values > 18)

    def residuals(self, o):
        LT, PT, F1, F2 = o.LT101.values, o.PT101.values, o.FT101.values, o.FT102.values
        Z1, Z2, U1, U2 = o.ZT101.values, o.ZT102.values, o.u_level_calc.values, o.u_press_calc.values
        n = len(o); K = self.k
        a = 1.0 - math.exp(-1.0 / self.tau)
        r1, r2, r3, r4 = (np.zeros(n) for _ in range(4))
        lh = LT[0]
        vg0 = max(self.vt * (1 - LT[0] / 100.0), 1.0)
        nh = PT[0] * vg0
        zl, zp = Z1[0], Z2[0]
        for t in range(n):
            vg = max(self.vt * (1 - LT[t] / 100.0), 1.0)
            ph = nh / vg
            r1[t] = LT[t] - lh
            r2[t] = PT[t] - ph
            r3[t] = Z1[t] - zl
            r4[t] = Z2[t] - zp
            # propagate observers to t+1
            lh += (F1[t] - F2[t]) / 3600.0 * 100.0 / self.vt + K * (LT[t] - lh)
            gin = self.gor * F1[t]
            gout = self.kg * (Z2[t] / 100.0) * math.sqrt(max(ph - self.p_down, 0.0))
            nh += (gin - gout) * P0 / 3600.0 + K * (PT[t] * vg - nh)
            zl += (U1[t] - zl) * a
            zp += (U2[t] - zp) * a
        return r1, r2, r3, r4

    def _fit(self, runs):
        R = [self.residuals(r) for r in runs]
        self.scale = [max(float(np.concatenate([x[i][120:] for x in R]).std()), 1e-9) for i in range(4)]

    def channel_scores(self, df):
        """(n,5) array: normalised |residual| for level, gas, valve_l, valve_p, and SP-envelope flag (0/1)."""
        from ..sim.runner import OBSERVABLE
        o = df[OBSERVABLE]
        r = self.residuals(o)
        ch = np.stack([np.abs(r[i]) / self.scale[i] for i in range(4)], axis=1)
        bad = self._sp_bad(o)
        ch[:WARMUP_] = 0.0
        return np.concatenate([ch, bad.astype(float)[:, None]], axis=1)

    def _score(self, o):
        r = self.residuals(o)
        names = ["level", "gas", "valve_l", "valve_p"]
        s = np.zeros(len(o))
        for i, nm in enumerate(names):
            if nm in self.use:
                s = np.maximum(s, np.abs(r[i]) / self.scale[i])
        if "sp" in self.use:
            s = np.where(self._sp_bad(o), BIG, s)
        return s
