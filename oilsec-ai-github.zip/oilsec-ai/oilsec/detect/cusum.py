import numpy as np
import pandas as pd
from .base import Detector

CH = ["LT101", "PT101", "TT101", "FT101", "FT102", "ZT101", "ZT102", "u_level_calc", "u_press_calc"]


class Cusum(Detector):
    """D2: two-sided CUSUM on standardised channels (autocorrelation NOT modelled)."""
    name = "D2_cusum"

    def __init__(self, k=0.5):
        super().__init__(); self.k = k

    def _fit(self, runs):
        allv = pd.concat([r[CH].iloc[120:] for r in runs])
        self.mu = allv.mean().values
        self.sd = np.maximum(allv.std().values, 1e-6)

    def _score(self, o):
        z = (o[CH].values - self.mu) / self.sd
        n, m = z.shape
        sp = np.zeros(m); sn = np.zeros(m); out = np.zeros(n)
        for t in range(n):
            sp = np.maximum(0.0, sp + z[t] - self.k)
            sn = np.maximum(0.0, sn - z[t] - self.k)
            out[t] = max(sp.max(), sn.max())
        return out
