import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
names={f.name for f in font_manager.fontManager.ttflist}
for cand in ("TeX Gyre Termes","Liberation Serif","Nimbus Roman","STIXGeneral","DejaVu Serif"):
    if cand in names: FONT=cand; break
plt.rcParams.update({"font.family":FONT,"font.size":7.5,"axes.linewidth":0.6,"axes.spines.top":False,"axes.spines.right":False,
                     "xtick.major.width":0.5,"ytick.major.width":0.5,"pdf.fonttype":42})
BLUE="#2f6fd0"; GREY="#8f8f86"; LGREY="#d6d6cf"; DASH="#555555"
print("font:",FONT)

# ---- Fig 1: detection (single column)
rows=[("A1 at −1",0,0,0,1),("A1 at −2",0,0,0,1),("A4 at 40",0,1,0,1),("A4 at 45",0,.575,0,1),("A5 at −0.0005",0,0,0,.975),
      ("A5 at −0.001",0,0,0,1),("A3 at 55",0,0,0,0),("A3 at 60",0,1,1,.025),("A3 at 65",0,1,1,.1)]
fig,ax=plt.subplots(figsize=(3.45,2.9))
for i,(lab,d1,d2,d3,d4) in enumerate(rows):
    y=len(rows)-1-i; best=max(d1,d2,d3)
    ax.scatter([best],[y-.17],s=22,color=LGREY,edgecolor=GREY,linewidth=.6,zorder=3)
    ax.scatter([d4],[y+.17],s=22,color=BLUE,zorder=4)
    f=lambda v: f"{v:.1f}" if v in (0,1) else f"{v:g}"
    ax.text(best+.035,y-.17,f(best),va="center",fontsize=6.3,color="#444")
    ax.text(d4+.035,y+.17,f(d4),va="center",fontsize=6.3,color="black")
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows][::-1])
ax.set_xlim(-.05,1.2); ax.set_xticks([0,.5,1]); ax.set_xlabel("Detection rate (independent replication, 40 seeds per condition)")
ax.grid(axis="x",color="#e6e6e6",lw=.5); ax.set_axisbelow(True)
ax.scatter([],[],s=22,color=BLUE,label="Twin (D4)"); ax.scatter([],[],s=22,color=LGREY,edgecolor=GREY,linewidth=.6,label="Best of rules, CUSUM, iForest")
ax.legend(loc="upper center",bbox_to_anchor=(.45,1.17),ncol=2,frameon=False,fontsize=6.5,handletextpad=.2,columnspacing=1)
fig.tight_layout(); fig.savefig("figures/fig1_detection.pdf"); fig.savefig("figures/fig1_detection.png",dpi=300); plt.close(fig)

# ---- Fig 2: accuracy vs baseline (a) and injection (b)  (two-column wide)
fig,(a,b)=plt.subplots(1,2,figsize=(7.1,2.35),gridspec_kw={"width_ratios":[1.15,1]})
models=["1.5B\n(fp16, n=89)","3B\n(fp16, n=89)","7B\n(4-bit, n=174)"]
acc={"signal":[.775,.169,.626],"ctx":[.787,.169,.356],"free text":[np.nan,np.nan,.793]}
base=[.775,.775,.782]
w=.24; x=np.arange(3)
cols={"signal":LGREY,"ctx":BLUE,"free text":GREY}
for k,(arm,vals) in enumerate(acc.items()):
    xs=x+(k-1)*w
    for xi,v in zip(xs,vals):
        if not np.isnan(v):
            a.bar(xi,v,w*.92,color=cols[arm],edgecolor=GREY if arm=="signal" else "none",linewidth=.4,label=arm if xi==xs[0] or (arm=="free text" and xi==xs[2]) else None)
            a.text(xi,v+.015,f"{v:.3f}",ha="center",fontsize=6)
for xi,bv in zip(x,base): a.hlines(bv,xi-.43,xi+.43,color=DASH,ls=(0,(4,2)),lw=.8)
a.hlines([],0,0,color=DASH,ls=(0,(4,2)),lw=.8,label="always attack")
a.set_xticks(x); a.set_xticklabels(models); a.set_ylim(0,1.0); a.set_ylabel("Accuracy"); a.set_title("(a) Accuracy against always-attack baseline",fontsize=7.5,loc="left")
h,l=a.get_legend_handles_labels(); seen={}; 
for hh,ll in zip(h,l): seen.setdefault(ll,hh)
a.legend(seen.values(),seen.keys(),loc="upper center",ncol=4,frameon=False,fontsize=6.3,bbox_to_anchor=(.5,-.28),handlelength=1.2,columnspacing=.9)
inj=[(0,69),(0,69),(85,136)]; inj2=[(69,69),(69,69),(136,136)]
w2=.34
for xi,(b0,t0),(b1,t1) in zip(x,inj,inj2):
    b.bar(xi-w2/2-.02,b0/t0,w2,color=LGREY,edgecolor=GREY,linewidth=.4); b.text(xi-w2/2-.02,b0/t0+.015,f"{b0}/{t0}",ha="center",fontsize=6)
    b.bar(xi+w2/2+.02,b1/t1,w2,color=BLUE); b.text(xi+w2/2+.02,b1/t1+.015,f"{b1}/{t1}",ha="center",fontsize=6)
b.set_xticks(x); b.set_xticklabels(["1.5B","3B","7B (4-bit)"]); b.set_ylim(0,1.12); b.set_yticks([0,.5,1]); b.set_ylabel("Attack episodes called benign")
b.set_title("(b) Verdict “benign” without and with injected note",fontsize=7.5,loc="left")
from matplotlib.patches import Patch
b.legend(handles=[Patch(facecolor=LGREY,edgecolor=GREY,linewidth=.4,label="no note"),Patch(facecolor=BLUE,label="injected note")],loc="upper center",ncol=2,frameon=False,fontsize=6.3,bbox_to_anchor=(.5,-.28),handlelength=1.2)
fig.tight_layout(); fig.savefig("figures/fig2_accuracy_injection.pdf"); fig.savefig("figures/fig2_accuracy_injection.png",dpi=300); plt.close(fig)

# ---- Fig 3: claim defects split (a) and IDS-flag effect (b)
import json
FN=json.load(open("../analysis/final_numbers.json"))
LBLUE="#a9c4ef"; DARK="#4d4d4d"
def rowd(c,label):
    n=c["total"]; return (label,n,c["integrity"]/n*100,c["dirnd"]/n*100,c["other"]/n*100,c["ci_integrity"])
rows=[rowd(FN["1.5B"]["claims_ctx"],"1.5B, structured"),rowd(FN["3B"]["claims_ctx"],"3B, structured"),rowd(FN["7B"]["claims_ctx"],"7B, structured"),
      rowd(FN["7B"]["freetext_claims"],"7B, claims from prose"),rowd(FN["7B"]["control_claims"],"7B, control (known-true text)")]
fig,(a,b)=plt.subplots(1,2,figsize=(7.1,2.45),gridspec_kw={"width_ratios":[1.35,1]})
for i,(lab,n,ig,dn,ot,ci) in enumerate(rows):
    y=len(rows)-1-i
    a.barh(y,ig,.55,color=BLUE); a.barh(y,dn,.55,left=ig,color=LBLUE,edgecolor=GREY,linewidth=.3); a.barh(y,ot,.55,left=ig+dn,color=DARK)
    a.plot([ci[0]*100,ci[1]*100],[y+.36,y+.36],color="black",lw=.7); a.plot([ci[0]*100]*2,[y+.31,y+.41],color="black",lw=.7); a.plot([ci[1]*100]*2,[y+.31,y+.41],color="black",lw=.7)
    a.text(ig+dn+ot+1.2,y,f"integrity {ig:.1f}% ({ci[0]*100:.1f}–{ci[1]*100:.1f})",va="center",fontsize=6.0)
a.set_yticks(range(len(rows))); a.set_yticklabels([f"{r[0]}\n({r[1]} claims)" for r in rows][::-1],fontsize=6.2)
a.set_xlim(0,82); a.set_xlabel("Defective claims (% of claims)"); a.set_title("(a) Claim defects by type",fontsize=7.5,loc="left")
from matplotlib.patches import Patch
a.legend(handles=[Patch(facecolor=BLUE,label="integrity (id or metric)"),Patch(facecolor=LBLUE,edgecolor=GREY,linewidth=.3,label="direction on non-delta"),Patch(facecolor=DARK,label="other")],
         loc="upper center",bbox_to_anchor=(.45,-.27),ncol=3,frameon=False,fontsize=6.0,handlelength=1.1,columnspacing=.8)
ids=FN["7B"]["ids"]; groups=[("IDS silent","silent"),("IDS alert","alert")]; x=np.arange(2); w=.34
for k,(arm,col,edge) in enumerate((("signal",LGREY,GREY),("ctx",BLUE,"none"))):
    for xi,(gl,key) in zip(x,groups):
        c,t=ids[arm][key]; xx=xi+(k-.5)*w*1.08
        b.bar(xx,c/t,w,color=col,edgecolor=edge,linewidth=.4); b.text(xx,c/t+.02,f"{c}/{t}",ha="center",fontsize=6)
b.set_xticks(x); b.set_xticklabels([f"{g[0]}\n(n={ids['signal'][g[1]][1]})" for g in groups]); b.set_ylim(0,1.1); b.set_yticks([0,.5,1]); b.set_ylabel("Attack episodes called attack")
b.set_title("(b) 7B: effect of the IDS flag",fontsize=7.5,loc="left")
b.legend(handles=[Patch(facecolor=LGREY,edgecolor=GREY,linewidth=.4,label="signal arm"),Patch(facecolor=BLUE,label="ctx arm")],loc="upper center",bbox_to_anchor=(.5,-.27),ncol=2,frameon=False,fontsize=6.3,handlelength=1.1)
fig.tight_layout(); fig.savefig("figures/fig3_claims_ids.pdf"); fig.savefig("figures/fig3_claims_ids.png",dpi=300); plt.close(fig)
print("ok")
