# Paper sources
`paper.tex` is the IEEEtran version (needs the `IEEEtran` class; compile with `pdflatex` twice). `make_figures.py` regenerates Figs. 1, 2, 3 of that version from `../analysis/final_numbers.json`; Fig. 4 (workflow) is a static vector drawing in `figures/`.
The journal (IJMRAI) manuscript is distributed separately with the submission.
