"""Exp02b — EXPLORATORY (not pre-registered). Interrogates Exp02. Usage: python3 exp02b_exploratory.py auc|mismatch|fusion"""
import sys, os, json, glob
import numpy as np
import pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp02_collect import conditions, training_runs, make_dets, T0, DUR, NORMAL_SEEDS, TEST_SEEDS
from oilsec.sim.runner import simulate, SimConfig
from oilsec.detect.base import sustained
from oilsec.detect.twin import Twin

mode = sys.argv[1]
C = conditions()
WEAK = ["A1_-1", "A1_-2", "A4_45", "A4_40", "A5_-0.0005", "A5_-0.001"]


def auc(pos, neg):
    pos, neg = np.asarray(pos), np.asarray(neg)
    return float(np.mean([(p > n) + 0.5 * (p == n) for p in pos for n in neg]))


if mode in ("auc", "auchard"):
    tr = training_runs(1)
    dets = [d.fit(tr) for d in make_dets()]
    conds = WEAK + ["A3_60", "A3_65", "A4_5", "A5_-0.01", "A1_-35"]
    peaks_norm = {d.name: [] for d in dets}
    wl = {c: C[c][2] for c in conds}
    for s in NORMAL_SEEDS:
        df = simulate(SimConfig(seed=s, duration_s=DUR))
        for d in dets:
            ss = sustained(d.score(df))
            peaks_norm[d.name].append({c: float(ss[T0:wl[c]].max()) for c in conds})
    hard = {d.name: [] for d in dets}
    if mode == "auchard":
        for b in ("B1", "B2", "B3"):
            for s in TEST_SEEDS:
                df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(C[b][0])))
                for d in dets:
                    ss = sustained(d.score(df))
                    hard[d.name].append({c: float(ss[T0:wl[c]].max()) for c in conds})
    res = {}
    for c in conds:
        ev, _, wend = C[c]
        pk = {d.name: [] for d in dets}
        for s in TEST_SEEDS:
            df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(ev)))
            for d in dets:
                pk[d.name].append(float(sustained(d.score(df))[T0:wend].max()))
        res[c] = {d.name: round(auc(pk[d.name], [x[c] for x in peaks_norm[d.name]]), 3) for d in dets}
        if mode == "auchard":
            res[c] = {d.name: (res[c][d.name], round(auc(pk[d.name], [x[c] for x in hard[d.name]]), 3)) for d in dets}
        print(c, res[c], flush=True)
    pick = (lambda v: v[1]) if mode == "auchard" else (lambda v: v)
    weak_mean = {d.name: round(float(np.mean([pick(res[c][d.name]) for c in WEAK])), 3) for d in dets}
    print("MEAN AUC over weak set:", weak_mean)
    json.dump(dict(auc=res, weak_mean=weak_mean, thr={d.name: d.thr for d in dets}), open(f"results/exp02b_{mode}.json", "w"), indent=2)

elif mode == "mismatch":
    tr = training_runs(1)
    variants = {"exact": dict(), "kg x1.1": dict(kg_scale=1.1), "gor x0.9": dict(gor_scale=0.9), "v_total x1.1": dict(vt_scale=1.1),
                "valve tau x2": dict(tau_valve=10.0),
                "all 2%": dict(kg_scale=1.02, gor_scale=0.98, vt_scale=1.02), "all 5%": dict(kg_scale=1.05, gor_scale=0.95, vt_scale=1.05),
                "all 10% + tau x2 (=D4m)": dict(kg_scale=1.1, gor_scale=0.9, vt_scale=1.1, tau_valve=10.0)}
    dets = {k: Twin(name=k, **v).fit(tr) for k, v in variants.items()}
    out = {k: {"hits": 0, "n": 0, "by": {}} for k in variants}
    for c in WEAK:
        ev, _, wend = C[c]
        for s in TEST_SEEDS:
            df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(ev)))
            for k, d in dets.items():
                a = d.alerts(df); e = np.where(a & ~np.concatenate([[False], a[:-1]]))[0]
                hit = bool(((e >= T0) & (e < wend)).any())
                out[k]["hits"] += hit; out[k]["n"] += 1
                out[k]["by"].setdefault(c, 0); out[k]["by"][c] += hit
    for k in variants:
        print(f"{k:26s} TPR weak = {out[k]['hits']/out[k]['n']:.3f}   by condition: {out[k]['by']}", flush=True)
    json.dump(out, open("results/exp02b_mismatch.json", "w"), indent=2)

elif mode == "fusion":
    df = pd.concat([pd.read_csv(f) for f in sorted(glob.glob("results/exp02_runs_L*.csv"))], ignore_index=True)
    res = {}
    for lv in (1, 3, 5):
        x = df[(df.level == lv) & (df.protocol == "recal") & (df.condition != "NORMAL")]
        piv = x.pivot_table(index=["condition", "seed"], columns="detector", values="detected", aggfunc="first").astype(bool)
        fus = piv["D4_twin"] | piv["D3_iforest"] | piv["D2_cusum"]
        t = pd.DataFrame({"D4": piv["D4_twin"], "D4|D3|D2": fus}).groupby(level="condition").mean()
        nrm = df[(df.condition == "NORMAL") & (df.level == lv) & (df.protocol == "recal")]
        pn = nrm.pivot_table(index="seed", columns="detector", values="pre_fa", aggfunc="first").astype(bool)
        fpr = float((pn["D4_twin"] | pn["D3_iforest"] | pn["D2_cusum"]).mean())
        res[lv] = dict(fusion_fpr_normal=fpr, tpr=t.round(2).to_dict("index"))
        print(f"level x{lv}: OR-fusion FPR on 60 normal runs = {fpr:.3f}")
        sel = ["A3_55", "A3_60", "A3_65", "A5_-0.001", "A2", "B3", "F2"]
        print(t.loc[sel].round(2).to_string())
    json.dump(res, open("results/exp02b_fusion.json", "w"), indent=2, default=str)
