"""Experiment 01 — executes the pre-registered criteria V5-V9 (V1-V4 are unit tests).
Validation seeds: 100..129. Writes results/exp01_results.json and docs/figures/exp01_*.png
"""
import json, sys, os
import numpy as np
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from oilsec.sim.runner import simulate, SimConfig, TAGS, SENSOR_SIGMA
from oilsec.sim import scenarios as sc

SEEDS = list(range(100, 130))
OUT = {}
SP_L, SP_P = 50.0, 15.0


def ci95(x):
    x = np.asarray(x, float)
    if len(x) < 2 or x.std(ddof=1) == 0:
        return [float(x.mean())] * 2
    h = stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return [float(x.mean() - h), float(x.mean() + h)]


def run(seed, events=(), **kw):
    return simulate(SimConfig(seed=seed, duration_s=3600, events=tuple(events), **kw))


# ---------------- V5 numerical convergence ----------------
a = run(100, [sc.inlet_slug(600)], substeps=5)
b = run(100, [sc.inlet_slug(600)], substeps=50)
dL = float(np.abs(a.true_level - b.true_level).max())
dP = float(np.abs(a.true_pressure - b.true_pressure).max())
OUT["V5"] = dict(max_dL=dL, max_dP=dP, passed=bool(dL < 0.05 and dP < 0.02))

# ---------------- V6 normal operation ----------------
rows = []
for s in SEEDS:
    d = run(s)
    L, P = d.true_level.values, d.true_pressure.values
    rows.append(dict(
        lvl_in=float(np.mean(np.abs(L - SP_L) <= 5) * 100), p_in=float(np.mean(np.abs(P - SP_P) <= 0.5) * 100),
        trips=int(d.attrs["sis_trip_count"]), psv=float(d.truth_psv_lift.sum()),
        sat=float(np.mean((d.u_level_applied <= .5) | (d.u_level_applied >= 99.5) |
                          (d.u_press_applied <= .5) | (d.u_press_applied >= 99.5)) * 100),
        maxdev_L=float(np.abs(L - SP_L).max()), maxdev_P=float(np.abs(P - SP_P).max()),
        sd_L=float(L.std()), sd_P=float(P.std())))
col = lambda k: [r[k] for r in rows]
thrL, thrP = float(np.percentile(col("maxdev_L"), 99)), float(np.percentile(col("maxdev_P"), 99))
OUT["V6"] = dict(
    lvl_in_band_pct=dict(mean=float(np.mean(col("lvl_in"))), ci95=ci95(col("lvl_in")), min=min(col("lvl_in"))),
    p_in_band_pct=dict(mean=float(np.mean(col("p_in"))), ci95=ci95(col("p_in")), min=min(col("p_in"))),
    total_trips=sum(col("trips")), total_psv_steps=sum(col("psv")), max_sat_pct=max(col("sat")),
    level_sd=dict(mean=float(np.mean(col("sd_L"))), ci95=ci95(col("sd_L"))),
    pressure_sd=dict(mean=float(np.mean(col("sd_P"))), ci95=ci95(col("sd_P"))),
    maxdev_level_p99=thrL, maxdev_pressure_p99=thrP,
    passed=bool(min(col("lvl_in")) >= 99 and min(col("p_in")) >= 99 and sum(col("trips")) == 0
                and sum(col("psv")) == 0 and max(col("sat")) < 1))

# sensitivity (NOT the criterion): threshold from 200 extra normal runs
ext = [run(s) for s in range(1000, 1200)]
OUT["V6"]["sensitivity_threshold_200runs"] = dict(
    level_p99=float(np.percentile([np.abs(d.true_level - SP_L).max() for d in ext], 99)),
    pressure_p99=float(np.percentile([np.abs(d.true_pressure - SP_P).max() for d in ext], 99)))


# ---------------- V7 benign disturbances ----------------
def settle_time(x, target, tol, t_from):
    """first time >= t_from after which |x-target|<=tol for the rest of the run (None if never)."""
    ok = np.abs(x - target) <= tol
    ok[:int(t_from)] = True
    bad = np.where(~ok)[0]
    if len(bad) == 0:
        return 0.0
    last_bad = bad[-1]
    return None if last_bad >= len(x) - 1 else float(last_bad + 1 - t_from)


v7 = {}
for name, ev, t_from, tgt, tol, lim in [
    ("B1_slug", sc.inlet_slug(600), 720, 50, 2, 1200),
    ("B2_well_switch", sc.well_switch(600), 600, 50, 2, 1200),
    ("B3_operator_sp", sc.operator_setpoint(600, value=55.0), 600, 55, 1, 900)]:
    res = []
    for s in SEEDS:
        d = run(s, [ev])
        st = settle_time(d.true_level.values, tgt, tol, t_from)
        res.append(dict(trip=int(d.attrs["sis_trip_count"] > 0), settle=st,
                        peakL=float(np.abs(d.true_level - 50).max()),
                        peakP=float(np.abs(d.true_pressure - 15).max())))
    ok_settle = [r["settle"] is not None and r["settle"] <= lim for r in res]
    v7[name] = dict(trip_frac=float(np.mean([r["trip"] for r in res])),
                    settled_frac=float(np.mean(ok_settle)),
                    median_settle_s=float(np.median([r["settle"] for r in res if r["settle"] is not None] or [np.nan])),
                    median_peak_level_dev=float(np.median([r["peakL"] for r in res])),
                    median_peak_pressure_dev=float(np.median([r["peakP"] for r in res])),
                    passed=bool(np.mean([r["trip"] for r in res]) <= 0.05 and np.mean(ok_settle) >= 0.95))
OUT["V7"] = v7

# ---------------- V8 attack impact (paired) ----------------
def impact(d, which):
    if which == "P":
        dev = np.abs(d.true_pressure - SP_P).max(); thr = thrP
    else:
        dev = np.abs(d.true_level - SP_L).max(); thr = thrL
    return float(dev), bool(dev > thr or d.attrs["sis_trip_count"] > 0 or d.truth_psv_lift.sum() > 0)


v8 = {}
cases = {**{k: (f(600), "L") for k, f in sc.ATTACK_FACTORIES.items() if k != "A5_pressure_ramp"},
         "A5_pressure_ramp": (sc.attack_pressure_ramp(600), "P"),
         "B1_slug": (sc.inlet_slug(600), "L"), "B2_well_switch": (sc.well_switch(600), "L"),
         "B3_operator_sp": (sc.operator_setpoint(600), "L"),
         "F1_ft102_stuck": (sc.sensor_fault_stuck(600), "L"), "F2_lt101_stuck": (sc.sensor_fault_stuck_level(600), "L")}
for name, (ev, which) in cases.items():
    eff, devs, d_cf, trips = [], [], [], []
    for s in SEEDS:
        base = run(s)                  # counterfactual, same seed (common random numbers)
        d = run(s, [ev])
        dev, hit = impact(d, which)
        eff.append(hit); devs.append(dev); d_cf.append(impact(base, which)[0]); trips.append(d.attrs["sis_trip_count"] > 0)
    v8[name] = dict(impact_frac=float(np.mean(eff)), sis_trip_frac=float(np.mean(trips)),
                    median_max_dev=float(np.median(devs)), median_counterfactual_dev=float(np.median(d_cf)),
                    paired_delta_median=float(np.median(np.array(devs) - np.array(d_cf))),
                    passed=bool(np.mean(eff) >= 0.90) if name.startswith("A") else None)
OUT["V8"] = v8

# ---------------- V9 noise injection correctness ----------------
d = run(100, sensor_noise=True, disturbances=False)
truth_start = {"LT101": d.true_level, "PT101": d.true_pressure, "TT101": d.true_temp,
               "FT101": d.true_q_in, "FT102": d.true_q_out, "ZT101": d.true_zl, "ZT102": d.true_zp}
v9 = {}
for tag in TAGS:
    resid = (d[tag].values[1:] - truth_start[tag].values[:-1]) if tag in ("LT101", "PT101", "TT101", "FT102", "ZT101", "ZT102") \
        else (d[tag].values - truth_start[tag].values)
    v9[tag] = dict(measured_sd=float(resid.std(ddof=1)), configured=SENSOR_SIGMA[tag],
                   rel_err=float(abs(resid.std(ddof=1) / SENSOR_SIGMA[tag] - 1)))
    v9[tag]["passed"] = bool(v9[tag]["rel_err"] < 0.05)
OUT["V9"] = v9

os.makedirs("results", exist_ok=True)
with open("results/exp01_results.json", "w") as f:
    json.dump(OUT, f, indent=2)

# ---------------- figure ----------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, ax = plt.subplots(3, 3, figsize=(15, 9), sharex=True)
names = ["NORMAL", "A1_level_spoof", "A2_level_freeze", "A3_sp_tamper", "A4_valve_force", "A5_pressure_ramp",
         "B1_slug", "B3_operator_sp", "F2_lt101_stuck"]
for a_, nm in zip(ax.ravel(), names):
    ev = [] if nm == "NORMAL" else [cases[nm][0]]
    dd = run(100, ev)
    a_.plot(dd.t / 60, dd.true_level, label="true level %"); a_.plot(dd.t / 60, dd.LT101, lw=.5, alpha=.6, label="LT101 (PLC view)")
    a2 = a_.twinx(); a2.plot(dd.t / 60, dd.true_pressure, color="tab:red", lw=1, label="true P bar"); a2.set_ylim(10, 24)
    a_.axhline(85, ls=":", c="k", lw=.7); a_.set_ylim(0, 100); a_.set_title(nm, fontsize=10)
    if nm == "NORMAL":
        a_.legend(loc="lower left", fontsize=7); a2.legend(loc="lower right", fontsize=7)
for a_ in ax[-1]:
    a_.set_xlabel("minutes")
fig.suptitle("Exp01 scenarios (seed 100). dotted: SIS HH 85%")
fig.tight_layout(); os.makedirs("docs/figures", exist_ok=True); fig.savefig("docs/figures/exp01_scenarios.png", dpi=110)
print(json.dumps(OUT, indent=1))
