"""Exp02 — data collection per Notebook 03. Writes results/exp02_runs.csv (one row per run x detector).
Analysis is a SEPARATE script (exp02_analyze.py) so the analysis cannot be chosen after peeking.
Usage: python3 experiments/exp02_collect.py [levels...]   (default 1 3 5)
"""
import sys, os, time, json
import numpy as np
import pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from oilsec.sim.runner import simulate, SimConfig
from oilsec.sim import scenarios as sc
from oilsec.detect.rules import AlarmRules
from oilsec.detect.cusum import Cusum
from oilsec.detect.iforest import IForest
from oilsec.detect.twin import Twin
from oilsec.detect.base import WARMUP

T0, DUR = 900, 3600
TRAIN_SEEDS = range(2000, 2040)
TEST_SEEDS = range(3000, 3020)
NORMAL_SEEDS = range(3000, 3060)


def make_dets():
    return [AlarmRules(), Cusum(), IForest(), Twin(),
            Twin(kg_scale=1.1, gor_scale=0.9, vt_scale=1.1, tau_valve=10.0, name="D4m_twin")]


def conditions():
    C = {}
    for v in (-1, -2, -4, -8, -16, -35):
        C[f"A1_{v}"] = ([sc.attack_level_spoof(T0, offset=float(v))], "attack", T0 + 1500 + 600)
    for v in (55, 60, 65, 70, 80):
        C[f"A3_{v}"] = ([sc.attack_setpoint_tamper(T0, value=float(v))], "attack", T0 + 1500 + 600)
    for v in (45, 40, 30, 20, 10, 5):
        C[f"A4_{v}"] = ([sc.attack_valve_force(T0, value=float(v))], "attack", T0 + 1500 + 600)
    for r in (-0.0005, -0.001, -0.002, -0.005, -0.01):
        C[f"A5_{r}"] = ([sc.attack_pressure_ramp(T0, rate=r)], "attack", T0 + 600 + 600)
    C["A2"] = ([sc.attack_level_freeze(T0)], "attack", T0 + 1800 + 600)
    C["A2c"] = ([sc.attack_level_freeze(T0), sc.well_switch(T0 + 60, eid="B2c")], "attack", T0 + 1800 + 600)
    C["B1"] = ([sc.inlet_slug(T0)], "benign", T0 + 120 + 600)
    C["B2"] = ([sc.well_switch(T0)], "benign", DUR)
    C["B3"] = ([sc.operator_setpoint(T0, value=55.0)], "benign", DUR)
    C["F1"] = ([sc.sensor_fault_stuck(T0)], "fault", T0 + 1800 + 600)
    C["F2"] = ([sc.sensor_fault_stuck_level(T0)], "fault", T0 + 1800 + 600)
    return C


def training_runs(level):
    runs = []
    for i, s in enumerate(TRAIN_SEEDS):
        ev = ()
        if i >= 20:
            r = np.random.default_rng(s)
            t0 = int(r.integers(600, 2400))
            ev = (r.choice([sc.inlet_slug, sc.well_switch, lambda t: sc.operator_setpoint(t, value=55.0)])(t0),)
        runs.append(simulate(SimConfig(seed=s, duration_s=DUR, events=ev, dist_scale=float(level))))
    return runs


def rising_edges(a):
    return np.where(a & ~np.concatenate([[False], a[:-1]]))[0]


def main(levels):
    C = conditions()
    frozen = None
    t_all = time.time()
    for lv in levels:
        rows, thr_info = [], {}
        out = f"results/exp02_runs_L{lv}.csv"
        t_lv = time.time()
        tr = training_runs(lv)
        dets = [d.fit(tr) for d in make_dets()]
        thr_info[str(lv)] = {d.name: float(d.thr) for d in dets}
        if lv == 1:
            frozen = dets
        elif frozen is None:                      # frozen-x1 thresholds: refit x1 detectors (deterministic)
            frozen = [d.fit(training_runs(1)) for d in make_dets()]
        print(f"[level {lv}] trained in {time.time()-t_lv:.0f}s thr={thr_info[str(lv)]}", flush=True)

        # --- pure-normal runs (P1 / S1 FPR)
        for s in NORMAL_SEEDS:
            df = simulate(SimConfig(seed=s, duration_s=DUR, dist_scale=float(lv)))
            protos = [("recal", dets)] + ([("frozen_x1", frozen)] if lv != 1 else [])
            for proto, ds in protos:
                for d in ds:
                    a = d.alerts(df)
                    rows.append(dict(level=lv, protocol=proto, condition="NORMAL", cls="normal", seed=s,
                                     detector=d.name, detected=np.nan, delay=np.nan,
                                     pre_fa=bool(a[WARMUP:].any()), win_frac=float(a[WARMUP:].mean())))
        print(f"[level {lv}] normal runs done {time.time()-t_lv:.0f}s", flush=True)

        # --- event conditions
        for cname, (ev, cls, wend) in C.items():
            for s in TEST_SEEDS:
                df = simulate(SimConfig(seed=s, duration_s=DUR, events=tuple(ev), dist_scale=float(lv)))
                for d in dets:
                    a = d.alerts(df)
                    edges = rising_edges(a)
                    inwin = edges[(edges >= T0) & (edges < wend)]
                    rows.append(dict(level=lv, protocol="recal", condition=cname, cls=cls, seed=s, detector=d.name,
                                     detected=bool(len(inwin) > 0), delay=float(inwin[0] - T0) if len(inwin) else np.nan,
                                     pre_fa=bool(a[WARMUP:T0].any()), win_frac=float(a[T0:wend].mean())))
            print(f"[level {lv}] {cname} done  (elapsed {time.time()-t_all:.0f}s)", flush=True)
        pd.DataFrame(rows).to_csv(out, index=False)          # checkpoint after each level
        json.dump(thr_info, open(f"results/exp02_thresholds_L{lv}.json", "w"), indent=2)
    print("DONE", f"{time.time()-t_all:.0f}s", flush=True)


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    main([int(x) for x in sys.argv[1:]] or [1, 3, 5])
