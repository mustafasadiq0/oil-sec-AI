"""Exp02 analysis — implements ONLY the endpoints pre-registered in Notebook 03."""
import json, os, sys
import numpy as np
import pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import glob
df = pd.concat([pd.read_csv(f) for f in sorted(glob.glob("results/exp02_runs_L*.csv"))], ignore_index=True)
DETS = ["D1_rules", "D2_cusum", "D3_iforest", "D4_twin", "D4m_twin"]
R = {}


def cp(k, n):
    ci = stats.binomtest(int(k), int(n)).proportion_ci(method="exact")
    return [round(ci.low, 4), round(ci.high, 4)]


# ---------------- P1: false alarms, held-out normal runs, x1 recalibrated ----------------
n = df[(df.condition == "NORMAL") & (df.level == 1) & (df.protocol == "recal")]
P1 = {}
for d in DETS:
    x = n[n.detector == d]
    P1[d] = dict(n=int(len(x)), false_alarm_runs=int(x.pre_fa.sum()), rate=float(x.pre_fa.mean()),
                 ci95=cp(x.pre_fa.sum(), len(x)), passed=bool(x.pre_fa.mean() <= 0.05))
R["P1"] = P1

# ---------------- P2: weak-attack detection, paired McNemar, Holm ----------------
WEAK = ["A1_-1", "A1_-2", "A4_45", "A4_40", "A5_-0.0005", "A5_-0.001"]
w = df[(df.condition.isin(WEAK)) & (df.level == 1) & (df.protocol == "recal")]
piv = w.pivot_table(index=["condition", "seed"], columns="detector", values="detected", aggfunc="first").astype(bool)
P2 = {"weak_set": WEAK, "n_paired_runs": int(len(piv)),
      "tpr": {d: float(piv[d].mean()) for d in DETS}, "tpr_ci95": {d: cp(piv[d].sum(), len(piv)) for d in DETS}}
tests = []
for o in ["D1_rules", "D2_cusum", "D3_iforest"]:
    b = int((piv["D4_twin"] & ~piv[o]).sum()); c = int((~piv["D4_twin"] & piv[o]).sum())
    p = float(stats.binomtest(b, b + c, 0.5, alternative="greater").pvalue) if b + c > 0 else 1.0
    tests.append(dict(vs=o, twin_only=b, other_only=c, p_one_sided=p))
order = np.argsort([t["p_one_sided"] for t in tests])
m = len(tests)
for rank, i in enumerate(order):                      # Holm step-down
    tests[i]["p_holm"] = float(min(1.0, max(tests[j]["p_one_sided"] * (m - r) for r, j in enumerate(order[:rank + 1]))))
    tests[i]["reject_H0_at_0.05"] = bool(tests[i]["p_holm"] < 0.05)
P2["mcnemar_twin_vs"] = tests
P2["passed"] = bool(all(t["reject_H0_at_0.05"] for t in tests))
R["P2"] = P2

# ---------------- P3: A2 vs F2 identical outcomes ----------------
P3 = {}
for lv in sorted(df.level.unique()):
    a = df[(df.condition == "A2") & (df.level == lv)].set_index(["seed", "detector"])
    f = df[(df.condition == "F2") & (df.level == lv)].set_index(["seed", "detector"])
    same = bool((a.detected == f.detected).all() and (a.delay.fillna(-1) == f.delay.fillna(-1)).all()
                and (a.win_frac == f.win_frac).all())
    P3[f"level_{lv}"] = same
P3["passed"] = bool(all(P3.values()))
R["P3_A2_equals_F2"] = P3

# ---------------- S1: TPR tables, FPR frozen thresholds ----------------
ev = df[(df.condition != "NORMAL") & (df.protocol == "recal")]
tpr = ev.groupby(["level", "condition", "detector"]).detected.mean().unstack("detector")[DETS]
R["S1_tpr"] = {f"{lv}|{c}": {d: round(float(v), 3) for d, v in row.items()} for (lv, c), row in tpr.iterrows()}
S1f = {}
for lv in sorted(df.level.unique()):
    for proto in ("recal", "frozen_x1"):
        x = df[(df.condition == "NORMAL") & (df.level == lv) & (df.protocol == proto)]
        if len(x):
            S1f[f"level{lv}_{proto}"] = {d: dict(rate=float(x[x.detector == d].pre_fa.mean()),
                                                ci95=cp(x[x.detector == d].pre_fa.sum(), len(x[x.detector == d]))) for d in DETS}
R["S1_fpr_normal_runs"] = S1f
pre = ev.groupby(["level", "detector"]).pre_fa.mean().unstack("detector")[DETS]
R["S1_pre_event_false_alarm_rate_on_event_runs"] = {str(k): {d: round(float(v), 3) for d, v in r.items()} for k, r in pre.iterrows()}

# ---------------- S2: D4 vs D4m on weak set ----------------
b = int((piv["D4_twin"] & ~piv["D4m_twin"]).sum()); c = int((~piv["D4_twin"] & piv["D4m_twin"]).sum())
R["S2_twin_vs_mismatched"] = dict(D4_only=b, D4m_only=c, tpr_D4=float(piv["D4_twin"].mean()), tpr_D4m=float(piv["D4m_twin"].mean()),
                                  p_two_sided=float(stats.binomtest(b, b + c, 0.5).pvalue) if b + c else 1.0)

# ---------------- S3: delays ----------------
dl = ev[(ev.level == 1) & ev.detected.astype(bool)].groupby(["condition", "detector"]).delay.median().unstack("detector")[DETS]
R["S3_median_delay_s_x1"] = {c: {d: (None if pd.isna(v) else float(v)) for d, v in r.items()} for c, r in dl.iterrows()}

# ---------------- S4: benign/fault alert rate ----------------
bf = ev[ev.cls.isin(["benign", "fault"])].groupby(["level", "condition", "detector"]).detected.mean().unstack("detector")[DETS]
R["S4_benign_fault_alert_rate"] = {f"{lv}|{c}": {d: round(float(v), 3) for d, v in r.items()} for (lv, c), r in bf.iterrows()}

json.dump(R, open("results/exp02_analysis.json", "w"), indent=2)

# ---------------- figure ----------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fam = {"A1 level-sensor offset": ["A1_-1", "A1_-2", "A1_-4", "A1_-8", "A1_-16", "A1_-35"],
       "A3 level-SP tamper": ["A3_55", "A3_60", "A3_65", "A3_70", "A3_80"],
       "A4 valve force": ["A4_45", "A4_40", "A4_30", "A4_20", "A4_10", "A4_5"],
       "A5 pressure ramp": ["A5_-0.0005", "A5_-0.001", "A5_-0.002", "A5_-0.005", "A5_-0.01"]}
lvls = sorted(df.level.unique())
fig, ax = plt.subplots(len(lvls), 4, figsize=(17, 3.6 * len(lvls)), sharey=True, squeeze=False)
for i, lv in enumerate(lvls):
    for j, (title, conds) in enumerate(fam.items()):
        for d in DETS:
            ax[i][j].plot(range(len(conds)), [tpr.loc[(lv, c), d] for c in conds], marker="o", ms=4, label=d)
        ax[i][j].set_xticks(range(len(conds))); ax[i][j].set_xticklabels([c.split("_", 1)[1] for c in conds], fontsize=8)
        ax[i][j].set_title(f"{title}  (noise x{lv})", fontsize=9); ax[i][j].set_ylim(-0.03, 1.03)
        if j == 0: ax[i][j].set_ylabel("TPR (20 seeds)")
ax[0][0].legend(fontsize=7)
fig.suptitle("Exp02: detection rate vs attack intensity (weak -> strong, left -> right), recalibrated thresholds")
fig.tight_layout(); fig.savefig("docs/figures/exp02_tpr_curves.png", dpi=105)

# ---------------- console summary ----------------
print("P1 FPR (x1):", {d: f"{v['false_alarm_runs']}/{v['n']} ci{v['ci95']}" for d, v in P1.items()})
print("P2 weak-set TPR:", {d: round(v, 3) for d, v in P2["tpr"].items()})
for t in tests: print("   twin vs", t["vs"], t)
print("   P2 passed:", P2["passed"], "| P3 A2==F2:", P3)
print("S2:", R["S2_twin_vs_mismatched"])
print("S1 frozen-x1 FPR:", {k: {d: round(x["rate"], 3) for d, x in v.items()} for k, v in S1f.items()})
