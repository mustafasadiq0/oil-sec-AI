"""Replay the v2 parser/normaliser on the REAL v1 (Qwen2.5-3B) outputs. Needs notebooks/OilSec_AI_Colab.ipynb (python3 notebooks/assemble_colab.py)."""
import json, os, sys, re, collections
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(os.path.join(ROOT, "notebooks"))
os.environ.update(LLM_BACKEND="mock", SPLIT="dev", N_SEEDS="6", SKIP_IDS="1", N_JOBS="1",
                  OILSEC_REPO=ROOT)
nb = json.load(open("OilSec_AI_Colab.ipynb")); ns = {"__name__": "__main__"}
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code": continue
    tags = c["metadata"].get("tags", []); src = "".join(c["source"])
    if not ({"setup", "part1"} & set(tags)): continue
    if "# ---- Run the arms" in src or "# ---- Score the arms" in src: continue
    exec(compile(src, f"cell{i}", "exec"), ns)
EPS = ns["EPS"]
rows = [json.loads(l) for l in open(os.path.join(ROOT, "results/llm_v1_qwen2.5-3b/part1_llm_generations.jsonl"))]
RAW = collections.defaultdict(list)
for r in rows: RAW[r["arm"]].append(r)
# alignment check
for arm, lst in RAW.items():
    assert len(lst) == len(EPS), (arm, len(lst), len(EPS))
    assert all(lst[i]["cname"] == EPS[i]["cname"] for i in range(len(EPS))), arm
print("alignment OK:", len(EPS), "episodes (v1 dev seeds 6000-6005)")
P, V, N = ns["parse_json"], ns["validate"], ns["norm_obj"]; PT = ns["parse_json_tolerant"]
print("\n--- JSON arms: v1 strict vs v2 tolerant parser on the SAME raw 3B outputs")
for arm in ("signal", "ctx", "forged", "inject"):
    t = [r["text"] for r in RAW[arm]]
    s_ok = sum(V(P(x)) for x in t); t_ok = sum(V(N(PT(x))) for x in t)
    has_v = sum(isinstance(N(PT(x)), dict) and "verdict" in N(PT(x)) for x in t)
    print(f"{arm:7s} strict-valid {s_ok}/54 | tolerant-valid {t_ok}/54 | outputs containing a verdict key after repair: {has_v}/54")
print("\n--- control extractor (known-true narratives): unsupported-claim rate")
ctrl = [r["text"] for r in RAW["control_claims"]]
for norm in (False, True):
    nc = nv = nbad = 0
    for i, t in enumerate(ctrl):
        o = PT(t); cl = o.get("claims") if isinstance(o, dict) else None
        if not isinstance(cl, list): nbad += 1; continue
        a, b = ns["check_claims"](cl, ns["items_for"](EPS[i], True), normalize=norm); nc += a; nv += b
    print(f"normalize={norm!s:5s}: claims={nc} violations={nv} rate={nv/nc:.3f}  (unparseable extractions: {nbad}/54)")
print("\n--- free-text narratives: VERDICT line present:", sum(bool(ns['parse_verdict_line'](r['text'])[0]) for r in RAW['freetext_text']), "/54")
print("--- free-text extraction returned >=1 claim:", sum(bool((PT(r['text']) or {}).get('claims')) for r in RAW['freetext_claims']), "/54")

print("\n--- residual control violations (normalised): categorise")
from oilsec.triage.report import verify
import numpy as np
cat = collections.Counter(); ex = {}
for i, t in enumerate(ctrl):
    items = ns["items_for"](EPS[i], True); by = {it["id"]: it for it in items}
    cl = ns["norm_claims"](PT(t)["claims"], items)
    for c in cl:
        ev = by.get(c.get("cite"))
        if ev is None: k = "cite not in package"
        elif c.get("metric") != ev["key"]: k = "metric != key of cited id"
        elif c["type"] == "numeric":
            try: ok = abs(ev["value"] - float(c["value"])) <= max(1e-6, 0.01 * abs(ev["value"]))
            except Exception: ok = False
            k = None if ok else "numeric value off"
        else:
            k = None if c.get("direction") == ("increase" if ev["value"] > 0 else "decrease") else "direction wrong"
        if k: cat[k] += 1; ex.setdefault(k, (c, ev))
print(dict(cat))
for k, (c, ev) in ex.items(): print(" ", k, "| claim", c, "| evidence", ev)
