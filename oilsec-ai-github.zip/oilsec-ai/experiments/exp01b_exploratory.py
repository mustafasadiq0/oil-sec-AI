"""Exp01b — EXPLORATORY follow-up (not pre-registered). Interrogates anomalies seen in Exp01.
Validation seeds 100..129. Output: results/exp01b_output.txt (stdout captured by caller)."""
import sys, os
import numpy as np, pandas as pd
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from oilsec.sim.runner import simulate, SimConfig, OBSERVABLE
from oilsec.sim import scenarios as sc
run = lambda s, ev=(), **k: simulate(SimConfig(seed=s, duration_s=3600, events=tuple(ev), **k))
S = range(100, 130)

a = run(100, [sc.attack_level_freeze(600)]); f = run(100, [sc.sensor_fault_stuck_level(600)])
print("A2 vs F2 observable columns bit-identical:", all(np.array_equal(a[c].values, f[c].values) for c in OBSERVABLE),
      "| steps with differing label:", int((a.label != f.label).sum()))
b = run(100); f1 = run(100, [sc.sensor_fault_stuck(600)])
print("F1 process truth identical to counterfactual:",
      all(np.array_equal(b[c].values, f1[c].values) for c in b.columns if c.startswith(("true_", "truth_"))))

print("\nSeverity (30 seeds): alarm = L>70 | L<30 | P>18 ; avail = inlet throughput vs nominal")
cases = [("NORMAL", None), ("A1", sc.attack_level_spoof(600)), ("A2", sc.attack_level_freeze(600)),
         ("A3", sc.attack_setpoint_tamper(600)), ("A4", sc.attack_valve_force(600)),
         ("A5", sc.attack_pressure_ramp(600)), ("B1", sc.inlet_slug(600)), ("B3", sc.operator_setpoint(600))]
for nm, ev in cases:
    r = []
    for s in S:
        d = run(s, [ev] if ev else [])
        L, P = d.true_level, d.true_pressure
        r.append(dict(alarm=bool((L > 70).any() or (L < 30).any() or (P > 18).any()), trip=d.attrs["sis_trip_count"] > 0,
                      avail=100 * d.true_q_in.sum() / 360000, minP=P.min(), peakP=P.max(), peakL=L.max()))
    r = pd.DataFrame(r)
    line = f"  {nm:6s} alarm={r.alarm.mean():.2f} trip={r.trip.mean():.2f} avail={r.avail.mean():5.1f}% peakL={r.peakL.mean():5.1f} peakP={r.peakP.mean():5.2f} minP={r.minP.min():5.2f}"
    if ev and nm in ("A1", "A3", "A4"):
        c = Counter()
        for s in S:
            d = run(s, [ev])
            if d.sis_tripped.max() > 0:
                i = int(np.argmax(d.sis_tripped.values > 0)); j = max(i - 1, 0)
                c["P-high" if d.true_pressure.values[j] > 18.5 else ("L-high" if d.true_level.values[j] > 84 else "other")] += 1
        line += f" first-trip-channel={dict(c)}"
    print(line)
d = run(100); print("\nPLC output one-step sd (normal):", round(float(np.diff(d.u_level_calc).std()), 3),
                    "% | actual valve one-step sd:", round(float(np.diff(d.true_zl).std()), 3), "%")
